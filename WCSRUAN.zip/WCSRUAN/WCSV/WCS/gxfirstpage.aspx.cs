using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using com.sabratec.applinx.baseobject;

/// <summary>
/// Summary description for gxfirstpage.
/// </summary>
public partial class gxfirstpage : GXBasicWebForm
{
    private void Page_Load(object sender, System.EventArgs e)
    {
        try
        {
            gx_connect();
            gx_handleHostResponse();
        }
        catch (GXGeneralException err)
        {
            gx_handleSessionError(err);
        }
    }
    protected override void OnPreRender(EventArgs e)
    {
        long timeout = 2000;    // not sure if this is ms or secs
        long flicker = 500;    // not sure if this is ms or secs

        GXGetScreenRequest req1 = new GXGetScreenRequest();
        GXIWaitCondition wcon1 = new GXWaitForScreen("WCSLOGON", timeout, flicker);
        req1.addWaitCondition(wcon1);

        timeout = 10000;    // not sure if this is ms or secs
        flicker = 2500;    // not sure if this is ms or secs

        GXGetScreenRequest req2 = new GXGetScreenRequest();
        GXIWaitCondition wcon2 = new GXWaitForScreen("IS0003", timeout, flicker);
        req2.addWaitCondition(wcon2);

        timeout = 10000;    // not sure if this is ms or secs
        flicker = 500;     // not sure if this is ms or secs

        GXGetScreenRequest req3 = new GXGetScreenRequest();
        GXIWaitCondition wcon3 = new GXWaitForScreen("DELCDEC", timeout, flicker);
        req3.addWaitCondition(wcon3);

        base.OnPreRender(e);
    }


    #region Web Form Designer generated code
    override protected void OnInit(EventArgs e)
    {
        //
        // CODEGEN: This call is required by the ASP.NET Web Form Designer.
        //
        InitializeComponent();
        base.OnInit(e);
    }

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.Load += new System.EventHandler(this.Page_Load);
    }
    #endregion
}
