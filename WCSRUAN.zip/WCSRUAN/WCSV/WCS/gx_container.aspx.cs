using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

	/// <summary>
	/// Summary description for gx_container.
	/// </summary>
	public partial class gx_container : System.Web.UI.Page
	{
		//protected HtmlGenericControl gx_mainPage;
		protected override void OnLoad(System.EventArgs e){
			base.OnLoad(e);
			String gx_page = Request["gx_page"];
			if (gx_page == null){
				gx_page = "gxfirstpage.aspx";
			}
			gx_mainPage.Attributes["src"] = gx_page;
		}

	}
