using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using com.sabratec.applinx.baseobject;

/// <summary>
/// Summary description for logoff.
/// </summary>
public partial class logoff : GXBasicWebForm
{
    private void Page_Load(object sender, System.EventArgs e)
    {

        try
        {
            gx_disconnect();
        }
        catch
        {
            Response.Write("<script>window.close();</script>");
        }

        if (Request.QueryString["gx_close"] == null)
        {
            Response.Write("<script>window.close();</script>");
            Response.Write("<script>top.location.href='WCS_app.htm'</script>");
        }
        else
        {
            Response.Write("<script>window.close();</script>");
        }
    }

    #region Web Form Designer generated code
    override protected void OnInit(EventArgs e)
    {
        //
        // CODEGEN: This call is required by the ASP.NET Web Form Designer.
        //
        InitializeComponent();
        base.OnInit(e);
    }

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.Load += new System.EventHandler(this.Page_Load);
    }
    #endregion
}
