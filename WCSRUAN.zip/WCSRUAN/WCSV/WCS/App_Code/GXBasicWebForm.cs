using System;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.HtmlControls;

using com.sabratec.util;
using com.sabratec.applinx.framework;
using com.sabratec.applinx.baseobject;
using com.sabratec.dotnet.framework.events;
using com.sabratec.applinx.baseobject.table;
using com.sabratec.dotnet.framework.web.tables;
using com.sabratec.dotnet.ci;
using com.sabratec.applinx.framework.emulation.ftp.dialog;
using com.sabratec.util.logger;

using com.sabratec.applinx.framework.web;

/// <summary>
/// Summary description for GXAbstractWebPage.
/// </summary>
public class GXBasicWebForm : com.sabratec.dotnet.framework.web.GXScreenBasedWebForm
{

    /****************************************************************************************************************************
            ApplinX configuration is in config/gx_appConfig.xml
    *****************************************************************************************************************************/
    public override void gx_initSessionConfig()
    {

        // Optional variables for all the project pages, list of variables can be found in the documentation

        //for device name 
        //gx_appConfig.SessionConfig.addVariable(GXBaseObjectConstants.GX_VAR_DEVICE_NAME, "<YOUR_DEVICE_NAME>");

        // Setting ApplinX session ID
        //gx_appConfig.getSessionConfig().setSessionId("<YOUR_SESSION_ID>");
    }

    protected override void OnInit(EventArgs e)
    {

        base.OnInit(e);

        // customize gx_appConfig settings from code here

        // FTP configuration
        //gx_appConfig.FtpConfig.setHostType(GXFtpConfig.GX_FTP_BYAPPLINX);
        //gx_appConfig.FtpConfig.setHostType(GXFtpConfig.GX_FTP_AS400);
        // End FTP configuration

        // Events capturing
        this.gx_preConnect += new GXPreConnectEventHandler(user_preConnect);
        this.gx_postConnect += new GXPostConnectEventHandler(user_postConnect);
        this.gx_preSendKeys += new GXPreSendKeyEventHandler(user_preSendKeys);
        this.gx_postSendKeys += new GXPostSendKeyEventHandler(user_postSendKeys);
        this.gx_screenSeqMismatch += new GXScreenSeqMismatchEventHandler(user_screenSeqMismatch);
        this.gx_changeNextForm += new GXChangeNextFormEventHandler(user_changeNextForm);
        this.gx_preSyncHostWithForm += new GXPreSyncHostWithFormEventHandler(user_preSyncHostWithForm);
        this.gx_preFillForm += new EventHandler(user_preFillForm);
        this.gx_postFillForm += new EventHandler(user_postFillForm);
        this.gx_preOpenWin += new GXPreOpenWinEventHandler(user_preOpenWin);
        // End of events capturing

        //user exit for HostKeys control
        //gx_appConfig.setHostKeysTagUserExit(new UserHostKeysTagTransform());
    }

    protected void user_preConnect(object sender, GXPreConnectEventArgs e)
    {
        // Occurs before gx_connect , gx_attach 
        // Use e.isNewSession  to know if the user is going to be attached to an existing session or connecting to a new one. 
        // Use e.sessionConfig to change the connect to ApplinX server parameters
    }

    protected void user_postConnect(object sender, GXPostConnectEventArgs e)
    {
        // occurs after gx_connect , gx_attach 
        // use e.isNewSession to know if the user was attached to an existing session or connected to a new one.
    }

    protected void user_screenSeqMismatch(object sender, GXScreenSeqMismatchEventArgs e)
    {
        // Occurs if the form seq. screen number is different from the gx_session seq. screen number.
        // Use e.sendToHost  to send the data to the host any way.
    }

    protected void user_preSendKeys(object sender, GXPreSendKeyEventArgs e)
    {
        // Occurs before gx_processHostKeyRequest(GXSendKeysRequest sendKeyRequest),
        // which is activated from a browser pf key or when ENTER is pressed, or javascript:gx_SubmitKey(key).
        // Use e.sendKeyRequest to change the send key request to ApplinX server.

    }

    protected void user_postSendKeys(object sender, GXPostSendKeyEventArgs e)
    {
        // Occurs after gx_processHostKeyRequest(GXSendKeysRequest sendKeyRequest),
        // which is activated from a browser pf key or when ENTER is pressed, or javascript:gx_SubmitKey(key)

    }

    protected void user_changeNextForm(object sender, GXChangeNextFormEventArgs e)
    {
        // occurs before loading next page , by gx_handleHostResponse
        // use e.nextForm , for example logon.aspx , to change the next page

    }

    protected void user_preFillForm(object sender, EventArgs e)
    {
        // Occurs before gx_fillForm() or gx_fillForm(GXScreensCollection screen)

    }

    protected void user_postFillForm(object sender, EventArgs e)
    {
        // Occurs after gx_fillForm() or gx_fillForm(GXScreensCollection screen)
    }
    protected void user_preSyncHostWithForm(object sender, GXPreSyncHostWithFormEventArgs e)
    {
        // Occurs in before gx_syncHostWithForm , used to add parameters to the map path
    }

    public override void gx_processHostKeyRequest(GXSendKeysRequest sendKeyRequest)
    {
        // This function is activated from a browser pf key or enter was pressed , or javascript:gx_SubmitKey(key)
        base.gx_processHostKeyRequest(sendKeyRequest);
    }

    // User exits for pop-ups manager
    public override void gx_refreshWindow(Object sender, EventArgs e)
    {
        // Occurs when a modal window is closed , the event is on the main window page
        base.gx_refreshWindow(sender, e);
    }
    public override void gx_closeWindow(Object sender, EventArgs e)
    {
        // Occurs when a modal window is closed, in the modal window page

        base.gx_closeWindow(sender, e);

        //gx_doCloseWindow("[pf3]");
    }

    protected void user_preOpenWin(object sender, GXPreOpenWinEventArgs e)
    {
        // Occurs before a window is opened, use e.openWin = false, to cancel opening the window,
        // and to change the window size.

        //			if (gx_session.getScreen().getName() ==  ...){
        //				e.openWin = false;
        //			}
    }
    // End of user exits for pop-ups manager 

    // User exits for tables
    public override void gx_changeTr(int RowIndex, HtmlTableRow tr, GXITableRow row)
    {
        // Occurs every time a new table row (TR) with run-time data is created.
        // Allows you to customize the TR according to the current host row.

        // if a certain field contains dashes hide the row
        //				if (row.getItemContent("<COLUMN_NAME>").IndexOf("---") >= 0){
        //					tr.Visible = false;
        //				}
    }
    public override void gx_changeTd(int ColIndex, HtmlTableCell td, GXITableRow row)
    {
        //Occurs every time a new table cell TD with run-time data is created.
        //Allows you to customize the table data TD according to the current host
        //row.

        // if a certain field is hidden, change the css class name to a disabled CSS class
        //				if ( ((GXFieldTableCell)row.getItem("<COLUMN_NAME>")).isVisible() == true){
        //					td.Attributes["class"] = "<DISABLE_GRAY_CSS_CLASS_NAME>";
        //				}
    }
    public override void gx_changeControl(int ColIndex, HtmlTableCell td, Control ctrl, GXITableRow row)
    {
        // Occurs every time a new control inside a TD with run-time data is created.
        // Allows you to customize the controls according to the current host row.

        // if the created element is a link, get it's content from a desired column
        //				if (ctrl is HtmlAnchor){
        //					HtmlAnchor myAnchor= (HtmlAnchor)ctrl;
        //					myAnchor.InnerHtml = row.getItemContent("<COLUMN_NAME>");
        //				}
    }
    // End of user exits for tables

}
