using System;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;

	/// <summary>
	/// This class is receiving an event on the creation of each type of tag
	/// such as: "onNewTextField", "onNewLabel", "onNewButton", etc. It should be used for tag
	/// level manipulations, such as changing the content and attributes, adding icons, etc.
	/// </summary>
	public class UserTagTransform1 : GXTagListener
	{
		public override void onNewLabel(GXRenderEvent e, GXILabelTag label) 
		{
			// Add here code that handles label fields (Host protected fields).
			// Use e parameter to access the screen tag model and the host screen.
		}
		public override void onNewTextField(GXRenderEvent e,GXITextFieldTag textField) 
		{
			// Add here code that handles text fields (Host unprotected fields).
			// Use e parameter to access the screen tag model and the host screen.
		}

		public override void onNewButton(GXRenderEvent e, GXIButtonTag button) 
		{
			// Add here code that handles instant buttons (Host keys for example).
			// Use e parameter to access the screen tag model and the host screen.
		}
		public override void onNewLink(GXRenderEvent e, GXILinkTag link) 
		{
			// Add here code that handles instant links (Host keys for example).
			// Use e parameter to access the screen tag model and the host screen.
		}
	
		public override void onNewCheckbox(GXRenderEvent e, GXICheckboxTag checkbox) 
		{
			// Add here code that handles instant checkboxes (As defined in ApplinX composer).
			// Use e parameter to access the screen tag model and the host screen.
		}
		public override void onNewCombobox(GXRenderEvent e, GXIComboboxTag combox) 
		{
			// Add here code that handles instant combo-boxes (As defined in ApplinX composer).
			// Use e parameter to access the screen tag model and the host screen.
		}
		public override void onNewRadioButtonGroup(GXRenderEvent e,GXIRadioButtonGroupTag radioGroup) 
		{
			// Add here code that handles instant radio buttons (As defined in ApplinX composer).
			// Use e parameter to access the screen tag model and the host screen.
		}

		public override void onNewTable(GXRenderEvent e, GXITableTag table) 
		{
			// Add here code that handles tables (As defined in ApplinX composer).
			// Use e parameter to access the screen tag model and the host screen.
		}
		public override void onNewTableCell(GXRenderEvent e,GXITableCellTag tableCell) 
		{
			// Add here code that handles table rows (as children of onNewTableRow).
			// Use e parameter to access the screen tag model and the host screen.
		}
		public override void onNewTableRow(GXRenderEvent e,GXITableRowTag tableRow) 
		{
			// Add here code that handles table cells (as children of onNewTableRow).
			// Use e parameter to access the screen tag model and the host screen.
		}

	}
