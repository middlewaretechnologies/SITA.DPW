using com.sabratec.applinx.baseobject;
using com.sabratec.applinx.presentation;
using com.sabratec.applinx.presentation.queries;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;
using com.sabratec.applinx.presentation.tags.html;
using com.sabratec.util;

	/// <summary>
	/// This class is receiving an "onComplete" event, 
	/// which should be used for manipulating the entire tag model.
	/// </summary>
/**
 * This transformation handles menu screens. It removes unrequired labels from the menu 
 * screen and builds an HTML table with the menu items appearing as links.
 * 
 * Handles transformation for the following maps:
 * 
 *			Database selection
 */
public class WCSM0281Transform :GXICompletionListener
{
	/**
	 * Hides elements that are not required to be displayed
	 * @param screenModel
	 *          The screen tag model whose elements should be hidden 
	 */
	private void hideElements(GXIScreenTagModel screenModel)
	{
		/** Executes a query for fields that contain one of the strings and hides them */
		GXTextQuery query = new GXTextQuery("Choice");
		query.addSearchText("Option");
				
		GXTagList list = screenModel.executeQuery(query);

			for(int i=0;i<list.getCount();i++)
				{
					list.get(i).setVisible(false);
				}

				/** also hides the Selection text field */
				hideSelectionField(screenModel);
	}
	
	/**
	 * Builds a table with menu items.
	 * Each menu text is created as a table cell.
	 * The menu number is not displayed.
	 * The link activates a JavaScript function <code>placeMenuOption</code> which places the number
	 * within the Selection text field.
	 * The JavaScript function is located in the js/general.js file
	 * @param screenModel
	 *          The screen tag model which should contain the menu items.   
	 */
	private void handleMenuItems(GXIScreenTagModel screenModel)
	{

		GXAreaQuery areaQuery = new GXAreaQuery(10,12);

		GXTagList list = screenModel.executeQuery(areaQuery);
		
		GXITableTag tableText= GXHtmlTagFactory.instance().newTable();
		
		GXITableRowTag trText = null;

		GXITableCellTag tc1Text = GXHtmlTagFactory.instance().newTableCell();
		GXITableCellTag tc2Text = null;
		GXITableCellTag tc3Text = null;
		
		GXITableTag tableButton = GXHtmlTagFactory.instance().newTable();
		GXITableRowTag trButton = null;

		GXITableCellTag tc1Button = GXHtmlTagFactory.instance().newTableCell();
		GXITableCellTag tc2Button = null;
		GXITableCellTag tc3Button = null;
		GXILinkTag href1Button = null;
		GXILinkTag href2Button = null;
		GXILinkTag href3Button = null;
		GXHtmlGenericTag img1Button = null;
		GXHtmlGenericTag img2Button = null;
		GXHtmlGenericTag img3Button = null;
		int countEnv = 0;
				
		for(int i=0;i<list.getCount();i=i+2)
		{
			GXILabelTag currentTag = (GXILabelTag)list.get(i);
			string optionNumber = currentTag.getText().Replace(".","").Trim();
			currentTag = (GXILabelTag)list.get(i+1);
			string optionText = currentTag.getText().Trim();
			
			if (optionNumber != null && optionNumber.Trim().Length > 0)
			{
				try
				{
					/** Checks if the option text is a number */
					int optionNumberInt = System.Int32.Parse(optionNumber);

					//tc1Text.setText(optionText);
					if (optionText == "Name")
					{
						countEnv = countEnv + 1;
						tc1Text = GXHtmlTagFactory.instance().newTableCell();
						tc1Text.setText(optionText);
						tc1Text.setAttribute("onmouseout","window.status=''; this.className='env_cell_text';");
						tc1Text.setAttribute("onmouseover","window.status='" + optionText + "'; this.className='env_cell_over';");
						tc1Text.setAttribute("onclick","placeM0281('" + optionNumber + "')");
						tc1Text.setAttribute("title",optionText);
						tc1Text.setAttribute("class","env_cell_text");

						tc1Button = GXHtmlTagFactory.instance().newTableCell();
						img1Button = GXHtmlTagFactory.instance().newGenericTag("img");
						img1Button.setAttribute("onclick","placeM0281('" + optionNumber + "')");
						href1Button = GXHtmlTagFactory.instance().newLink("");
						img1Button.setAttribute("src", "images/sort_desc.gif");
						tc1Button.setAttribute("class","env_cell_img");
					}
					else
					{
						if (optionText == "Code")
						{
							countEnv = countEnv + 1;
							tc2Text = GXHtmlTagFactory.instance().newTableCell();
							tc2Text.setText(optionText);
							tc2Text.setAttribute("onmouseout","window.status=''; this.className='env_cell_text';");
							tc2Text.setAttribute("onmouseover","window.status='" + optionText + "'; this.className='env_cell_over';");
							tc2Text.setAttribute("onclick","placeM0281('" + optionNumber + "')");
							tc2Text.setAttribute("title",optionText);
							tc2Text.setAttribute("class","env_cell_text");

							tc2Button = GXHtmlTagFactory.instance().newTableCell();
							img2Button = GXHtmlTagFactory.instance().newGenericTag("img");
							img2Button.setAttribute("onclick","placeM0281('" + optionNumber + "')");
							href2Button = GXHtmlTagFactory.instance().newLink("");
							img2Button.setAttribute("src", "images/sort_code.gif");
							tc2Button.setAttribute("class","env_cell_img");
						}
						else
						{
							if (optionNumber == "3")
							{

								countEnv = countEnv + 1;
								tc3Text = GXHtmlTagFactory.instance().newTableCell();
								tc3Text.setText(optionText);
								tc3Text.setAttribute("onmouseout","window.status=''; this.className='env_cell_text';");
								tc3Text.setAttribute("onmouseover","window.status='" + optionText + "'; this.className='env_cell_over';");
								tc3Text.setAttribute("onclick","placeM0281('" + optionNumber + "')");
								tc3Text.setAttribute("title",optionText);
								tc3Text.setAttribute("class","env_cell_text");

								tc3Button = GXHtmlTagFactory.instance().newTableCell();
								img3Button = GXHtmlTagFactory.instance().newGenericTag("img");
								img3Button.setAttribute("onclick","placeM0281('" + optionNumber + "')");
								href3Button = GXHtmlTagFactory.instance().newLink("");
								tc3Button.setAttribute("class", "buttonTD");
								img3Button.setAttribute("src", "images/sort_office.gif");
								tc3Button.setAttribute("class","env_cell_img");
							}
						}
					}
					
					list.get(i).setVisible(false);
					list.get(i+1).setVisible(false);
				}

				catch //(System.FormatException err)
				{
					/** Ignore when the text without the dot is not a number */
				}		
			}
		}
		trText = GXHtmlTagFactory.instance().newTableRow();
		tableText.getRows().add(trText);

		trButton = GXHtmlTagFactory.instance().newTableRow();
		trButton.setAttribute("class","env_row_img");
		tableButton.getRows().add(trButton);

		if (countEnv == 3)
		{
			trText.getCells().add(tc1Text);	

			href1Button.getChildren().add(img1Button);
			tc1Button.getChildren().add(href1Button);
			trButton.getCells().add(tc1Button);

			trText.getCells().add(tc2Text);	

			href2Button.getChildren().add(img2Button);
			tc2Button.getChildren().add(href2Button);
			trButton.getCells().add(tc2Button);
			
			trText.getCells().add(tc3Text);	

			href3Button.getChildren().add(img3Button);
			tc3Button.getChildren().add(href3Button);
			trButton.getCells().add(tc3Button);

			tableText.setAttribute("class","env_table_text3");
			tableButton.setAttribute("class","env_table_img3");
		}
		else
		{
			if (countEnv == 2)
			{
				trText.getCells().add(tc2Text);	

				href2Button.getChildren().add(img2Button);
				tc2Button.getChildren().add(href2Button);
				trButton.getCells().add(tc2Button);

				trText.getCells().add(tc1Text);	

				href1Button.getChildren().add(img1Button);
				tc1Button.getChildren().add(href1Button);
				trButton.getCells().add(tc1Button);

				tableText.setAttribute("class","env_table_text2");
				tableButton.setAttribute("class","env_table_img2");
			}
			else
			{
				trText.getCells().add(tc1Text);	

				href1Button.getChildren().add(img1Button);
				tc1Button.getChildren().add(href1Button);
				trButton.getCells().add(tc1Button);

				tableText.setAttribute("class","env_table_text1");
				tableButton.setAttribute("class","env_table_img1");
			}
		}

		screenModel.add(tableText);
		screenModel.add(tableButton);

		GXHtmlGenericTag iconImg = GXHtmlTagFactory.instance().newGenericTag("img");
		iconImg.setAttribute("src","images/sort_icon.gif");
		iconImg.setAttribute("class","iconImg");
		screenModel.add(iconImg);

		GXILabelTag sortLbl = GXHtmlTagFactory.instance().newLabel("Sort According To");
		sortLbl.setAttribute("id","sortLabel");
		screenModel.add(sortLbl);


	}
	
	/**
	 * Hides the selection menu field
	 * @param screeenModel
	 *      the screen tag model which contains the Selection field
	 */
	public void hideSelectionField(GXIScreenTagModel screeenModel) 
	{

		/** Checks if the field is the selection field */
		GXITag selectionTag;
		try 
		{
			selectionTag = screeenModel.executePositionQuery(14,31);
		} 
		catch //(GXIllegalPositionException e) 
		{
			return;
		}

		if (selectionTag != null)
		{
			selectionTag.setVisible(false,true); // render the tag with: style="display:none"
		}
	}

	public void onComplete(GXRenderEvent e) 
	{
		hideElements(e.getScreenTagModel());
		handleMenuItems(e.getScreenTagModel());
	}

}