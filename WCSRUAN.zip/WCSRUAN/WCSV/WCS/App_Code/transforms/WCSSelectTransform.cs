using com.sabratec.applinx.baseobject;
using com.sabratec.applinx.presentation;
using com.sabratec.applinx.presentation.queries;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;
using com.sabratec.applinx.presentation.tags.html;
using com.sabratec.util;

	/// <summary>
	/// This class is receiving an "onComplete" event, 
	/// which should be used for manipulating the entire tag model.
	/// </summary>
/**
 * This transformation handles menu screens. It removes unrequired labels from the menu 
 * screen and builds an HTML table with the menu items appearing as links.
 * 
 * Handles transformation for the following maps:
 * 
 *			Database selection
 */
public class WCSSelectTransform :GXICompletionListener
{
	/**
	 * Hides elements that are not required to be displayed
	 * @param screenModel
	 *          The screen tag model whose elements should be hidden 
	 */

	private void hideElements(GXIScreenTagModel screenModel)
	{
		/** Executes a query for fields that contain one of the strings and hides them */
		GXTextQuery query = new GXTextQuery("PLEASE ENTER YOUR CHOICE OF DATABASE (1 - 3):");
		query.addSearchText("PLEASE ENTER YOUR CHOICE OF DATABASE (1 - 2):");
				
		GXTagList list = screenModel.executeQuery(query);

			for(int i=0;i<list.getCount();i++)
				{
					list.get(i).setVisible(false);
				}

				/** also hides the Selection text field */
				hideSelectionField(screenModel);
	}
	
	/**
	 * Builds a table with menu items.
	 * Each menu text is created as a table cell.
	 * The menu number is not displayed.
	 * The link activates a JavaScript function <code>placeMenuOption</code> which places the number
	 * within the Selection text field.
	 * The JavaScript function is located in the js/general.js file
	 * @param screenModel
	 *          The screen tag model which should contain the menu items.   
	 */
	private void handleMenuItems(GXIScreenTagModel screenModel)
	{

		GXAreaQuery areaQuery = new GXAreaQuery(10,16);

		GXTagList list = screenModel.executeQuery(areaQuery);
		
		GXITableTag tableText= GXHtmlTagFactory.instance().newTable();
		
		GXITableRowTag trText = null;

		GXITableCellTag tcText = GXHtmlTagFactory.instance().newTableCell();
		GXITableCellTag tc1Text = null;
		GXITableCellTag tc2Text = null;
		GXITableCellTag tc3Text = null;
		
		GXITableTag tableButton = GXHtmlTagFactory.instance().newTable();
		GXITableRowTag trButton = null;

		GXITableCellTag tc1Button = GXHtmlTagFactory.instance().newTableCell();
		GXITableCellTag tc2Button = null;
		GXITableCellTag tc3Button = null;
		GXILinkTag href1Button = null;
		GXILinkTag href2Button = null;
		GXILinkTag href3Button = null;
		GXHtmlGenericTag img1Button = null;
		GXHtmlGenericTag img2Button = null;
		GXHtmlGenericTag img3Button = null;
		int countEnv = 0;
				
		for(int i=0;i<list.getCount();i=i+3)
		{
			GXILabelTag currentTag = (GXILabelTag)list.get(i);
			string optionNumber = currentTag.getText().Replace(".","").Trim();
			currentTag = (GXILabelTag)list.get(i+1);
			string optionText = currentTag.getText().Replace(";","").Trim();
			optionText = optionText.Replace("DATABASE","").Trim();
			
			if (optionNumber != null && optionNumber.Trim().Length > 0)
			{
				try
				{
					/** Checks if the option text is a number */
					int optionNumberInt = System.Int32.Parse(optionNumber);

					tcText.setText(optionText);
					if (optionText == "DEVELOPMENT")
					{
						countEnv = countEnv + 1;
						tc1Text = GXHtmlTagFactory.instance().newTableCell();
						tc1Text.setText("Development");
						tc1Text.setAttribute("onmouseout","window.status=''; this.className='env_cell_text';");
						tc1Text.setAttribute("onmouseover","window.status='" + "Development" + "'; this.className='env_cell_over';");
						tc1Text.setAttribute("onclick","placeSelectOption('" + optionNumber + "','Development')");
						tc1Text.setAttribute("title","Development");
						tc1Text.setAttribute("class","env_cell_text");
						tc1Text.setAttribute("id","Dev");

						tc1Button = GXHtmlTagFactory.instance().newTableCell();
						img1Button = GXHtmlTagFactory.instance().newGenericTag("img");
						img1Button.setAttribute("onclick","placeSelectOption('" + optionNumber + "','Development')");
						href1Button = GXHtmlTagFactory.instance().newLink("");
						img1Button.setAttribute("src", "images/env_dev.gif");
						tc1Button.setAttribute("class","env_cell_img");
						tc1Button.setAttribute("id","Dev");
					}
					else
					{
						if (optionText == "TEST")
						{
							countEnv = countEnv + 1;
							tc2Text = GXHtmlTagFactory.instance().newTableCell();
							tc2Text.setText("Test");
							tc2Text.setAttribute("onmouseout","window.status=''; this.className='env_cell_text';");
							tc2Text.setAttribute("onmouseover","window.status='" + "Test" + "'; this.className='env_cell_over';");
							tc2Text.setAttribute("onclick","placeSelectOption('" + optionNumber + "','Test')");
							tc2Text.setAttribute("title","Test");
							tc2Text.setAttribute("class","env_cell_text");
							tc2Text.setAttribute("id","Test");

							tc2Button = GXHtmlTagFactory.instance().newTableCell();
							img2Button = GXHtmlTagFactory.instance().newGenericTag("img");
							img2Button.setAttribute("onclick","placeSelectOption('" + optionNumber + "','Test')");
							href2Button = GXHtmlTagFactory.instance().newLink("");
							img2Button.setAttribute("src", "images/env_test.gif");
							tc2Button.setAttribute("class","env_cell_img");
							tc2Button.setAttribute("id","Test");
						}
						else
						{
							if (optionText == "PRODUCTION")
							{
								countEnv = countEnv + 1;
								tc3Text = GXHtmlTagFactory.instance().newTableCell();
								tc3Text.setText("Production");
								tc3Text.setAttribute("onmouseout","window.status=''; this.className='env_cell_text';");
								tc3Text.setAttribute("onmouseover","window.status='" + "Production" + "'; this.className='env_cell_over';");
								tc3Text.setAttribute("onclick","placeSelectOption('" + optionNumber + "','Production')");
								tc3Text.setAttribute("title","Production");
								tc3Text.setAttribute("class","env_cell_text");
								tc3Text.setAttribute("id","Prod");


								tc3Button = GXHtmlTagFactory.instance().newTableCell();
								img3Button = GXHtmlTagFactory.instance().newGenericTag("img");
								img3Button.setAttribute("onclick","placeSelectOption('" + optionNumber + "','Production')");
								href3Button = GXHtmlTagFactory.instance().newLink("");
								tc3Button.setAttribute("class", "buttonTD");
								img3Button.setAttribute("src", "images/env_prod.gif");
								tc3Button.setAttribute("class","env_cell_img");
								tc3Button.setAttribute("id","Prod");
							}
							else
							{
								GXHtmlGenericTag logoffImg = GXHtmlTagFactory.instance().newGenericTag("img");
								logoffImg.setAttribute("src","images/env_logoff.gif");
								logoffImg.setAttribute("class","env_logoff_img");
								logoffImg.setAttribute("onclick","placeSelectOption('" + optionNumber + "','Logoff')");
								logoffImg.setAttribute("title","Close Session");
								screenModel.add(logoffImg);

								GXILabelTag logoffLbl = GXHtmlTagFactory.instance().newLabel("Close Session");
								logoffLbl.setAttribute("class","env_logoff_text");
								logoffLbl.setAttribute("onmouseout","window.status=''; this.className='env_logoff_text'");
								logoffLbl.setAttribute("onmouseover","window.status='" + "Close Session" + "'; this.className='env_logoff_over'");
								logoffLbl.setAttribute("onclick","placeSelectOption('" + optionNumber + "','Logoff')");
								logoffLbl.setAttribute("title","Close Session");
								screenModel.add(logoffLbl);
	
							}
						}
					}
					
					list.get(i).setVisible(false);
					list.get(i+1).setVisible(false);
				}

				catch //(System.FormatException err)
				{
					/** Ignore when the text without the dot is not a number */
				}		
			}
		}
		trText = GXHtmlTagFactory.instance().newTableRow();
		tableText.getRows().add(trText);

		trButton = GXHtmlTagFactory.instance().newTableRow();
		trButton.setAttribute("class","env_row_img");
		tableButton.getRows().add(trButton);

		if (countEnv > 2)
		{
			trText.getCells().add(tc1Text);	

			href1Button.getChildren().add(img1Button);
			tc1Button.getChildren().add(href1Button);
			trButton.getCells().add(tc1Button);

			trText.getCells().add(tc2Text);	

			href2Button.getChildren().add(img2Button);
			tc2Button.getChildren().add(href2Button);
			trButton.getCells().add(tc2Button);
			
			trText.getCells().add(tc3Text);	

			href3Button.getChildren().add(img3Button);
			tc3Button.getChildren().add(href3Button);
			trButton.getCells().add(tc3Button);

			tableText.setAttribute("class","env_table_text3");
			tableButton.setAttribute("class","env_table_img3");
		}
		else
		{
			if (countEnv > 1)
			{
				trText.getCells().add(tc2Text);	

				href2Button.getChildren().add(img2Button);
				tc2Button.getChildren().add(href2Button);
				trButton.getCells().add(tc2Button);

				trText.getCells().add(tc3Text);	

				href3Button.getChildren().add(img3Button);
				tc3Button.getChildren().add(href3Button);
				trButton.getCells().add(tc3Button);

				tableText.setAttribute("class","env_table_text2");
				tableButton.setAttribute("class","env_table_img2");
			}
			else
			{
				trText.getCells().add(tc3Text);	

				href3Button.getChildren().add(img3Button);
				tc3Button.getChildren().add(href3Button);
				trButton.getCells().add(tc3Button);

				tableText.setAttribute("class","env_table_text1");
				tableButton.setAttribute("class","env_table_img1");
			}
		}

		screenModel.add(tableText);
		screenModel.add(tableButton);
	}
	
	/**
	 * Hides the selection menu field
	 * @param screeenModel
	 *      the screen tag model which contains the Selection field
	 */
	public void hideSelectionField(GXIScreenTagModel screeenModel) 
	{

		/** Checks if the field is the selection field */
		GXITag selectionTag;
		try 
		{
			selectionTag = screeenModel.executePositionQuery(20,65);
		} 
		catch //(GXIllegalPositionException e) 
		{
			return;
		}

		if (selectionTag != null)
		{
			selectionTag.setVisible(false,true); // render the tag with: style="display:none"
		}
	}

	public void onComplete(GXRenderEvent e) 
	{
		hideElements(e.getScreenTagModel());
		handleMenuItems(e.getScreenTagModel());
	}

}