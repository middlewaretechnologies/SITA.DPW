using com.sabratec.applinx.baseobject;
using com.sabratec.applinx.presentation;
using com.sabratec.applinx.presentation.queries;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;
using com.sabratec.applinx.presentation.tags.html;
using com.sabratec.util;

	/// <summary>
	/// This class is receiving an "onComplete" event, 
	/// which should be used for manipulating the entire tag model.
	/// </summary>
/**
 * This transformation handles menu screens. It removes unrequired labels from the menu 
 * screen and builds an HTML table with the menu items appearing as links.
  */
public class WCSM012ETransform :GXICompletionListener
{
	/**
	 * Hides elements that are not required to be displayed
	 * @param screenModel
	 *          The screen tag model whose elements should be hidden 
	 */
	private void hideElements(GXIScreenTagModel screenModel)
	{
		/** Executes a query for fields that contain one of the strings and hides them */
		
		GXTextQuery helpQuery = new GXTextQuery("Division");
		helpQuery.addSearchText("-");
		helpQuery.addSearchText("Div");
		helpQuery.addSearchText("Description");
		GXTagList helpList = screenModel.executeQuery(helpQuery);

		for(int i=0;i<helpList.getCount();i++)
		{
			helpList.get(i).setVisible(false);
		}
		/** also hides the Selection text field */
		hideSelectionField(screenModel);
	}
	
	/**
	 * Builds a table with menu items.
	 * Each menu text is created as a table cell.
	 * The menu number is not displayed.
	 * The link activates a JavaScript function <code>placeMenuOption</code> which places the number
	 * within the Selection text field.
	 * The JavaScript function is located in the js/general.js file
	 * @param screenModel
	 *          The screen tag model which should contain the menu items.   
	 */
	private void handleMenuItems(GXIScreenTagModel screenModel)
	{

		GXAreaQuery areaQuery = new GXAreaQuery(7,21);

		GXTagList list = screenModel.executeQuery(areaQuery);
		
		GXITableTag table1Text = GXHtmlTagFactory.instance().newTable();
		GXITableTag table2Text = GXHtmlTagFactory.instance().newTable();
		
		GXITableRowTag t1rText = null;
		GXITableRowTag t2rText = null;
		GXITableCellTag t1c1Text = null;
		GXITableCellTag t1c2Text = null;
		GXITableCellTag t2c1Text = null;
		GXITableCellTag t2c2Text = null;
		
		t1rText = GXHtmlTagFactory.instance().newTableRow();
		t2rText = GXHtmlTagFactory.instance().newTableRow();
		GXITableCellTag th1Text = GXHtmlTagFactory.instance().newTableCell();
		GXITableCellTag th2Text = GXHtmlTagFactory.instance().newTableCell();
		
		th1Text.setIsHeader(true);
		th2Text.setIsHeader(true);

		th1Text.setText("Div");
		th2Text.setText("Description");
		
		table1Text.getRows().add(t1rText);
		t1rText.getCells().add(th1Text);
		t1rText.getCells().add(th2Text);

		table2Text.getRows().add(t2rText);
		t2rText.getCells().add(th1Text);
		t2rText.getCells().add(th2Text);
		
		string altRow = "2";
				
		for(int i=0;i<list.getCount();i=i+4)
		{
			t1c1Text = GXHtmlTagFactory.instance().newTableCell();
			t1c2Text = GXHtmlTagFactory.instance().newTableCell();
			t2c1Text = GXHtmlTagFactory.instance().newTableCell();
			t2c2Text = GXHtmlTagFactory.instance().newTableCell();
   
			GXILabelTag currentTag = (GXILabelTag)list.get(i);
			string optionNumber = currentTag.getText().Replace(".","").Trim();

			if (optionNumber != null && optionNumber.Trim().Length > 0)
			{
				try
				{
					/** Checks if the option text is a number */
					int optionNumberInt = System.Int32.Parse(optionNumber);

					if (altRow == "2")
					{
						altRow = "1";
					}
					else
					{
						altRow = "2";
					}
					t1c1Text.setText(((GXILabelTag)list.get(i)).getText());
					t1c1Text.setAttribute("onclick","placeM012E('" + optionNumber + "')");
					t1c1Text.setAttribute("style","width=30px");

					t1c2Text.setText(((GXILabelTag)list.get(i+1)).getText());
					t1c2Text.setAttribute("onclick","placeM012E('" + optionNumber + "')");
					t1c2Text.setAttribute("style","width=250px");

					currentTag = (GXILabelTag)list.get(i+2);
					optionNumber = currentTag.getText().Replace(".","").Trim();

					t2c1Text.setText(((GXILabelTag)list.get(i+2)).getText());
					t2c1Text.setAttribute("onclick","placeM012E('" + optionNumber + "')");
					t2c1Text.setAttribute("style","width=30px");

					t2c2Text.setText(((GXILabelTag)list.get(i+3)).getText());
					t2c2Text.setAttribute("onclick","placeM012E('" + optionNumber + "')");
					t2c2Text.setAttribute("style","width=250px");

					t1rText = GXHtmlTagFactory.instance().newTableRow();
					t1rText.setAttribute("class","gx_tbl_alternating" + altRow);
					t1rText.setAttribute("onmouseover","this.className='helpw_over'");
					t1rText.setAttribute("onmouseout","this.className='helpw_out" + altRow + "'");
					t1rText.setAttribute("style","height=25px");

					t2rText = GXHtmlTagFactory.instance().newTableRow();
					t2rText.setAttribute("class","gx_tbl_alternating" + altRow);
					t2rText.setAttribute("onmouseover","this.className='helpw_over'");
					t2rText.setAttribute("onmouseout","this.className='helpw_out" + altRow + "'");
					t2rText.setAttribute("style","height=25px");


					table1Text.getRows().add(t1rText);
					t1rText.getCells().add(t1c1Text);
					t1rText.getCells().add(t1c2Text);

					table2Text.getRows().add(t2rText);
					t2rText.getCells().add(t2c1Text);
					t2rText.getCells().add(t2c2Text);

					
					list.get(i).setVisible(false);
					list.get(i+1).setVisible(false);
					list.get(i+2).setVisible(false);
					list.get(i+3).setVisible(false);
				}

				catch //(System.FormatException err)
				{
					/** Ignore when the text without the dot is not a number */
				}
				
			}
		}
		table1Text.setPosition(3,4);
		table1Text.setAttribute("class","gx_tbl");
		screenModel.add(table1Text);

		table2Text.setPosition(3,52);
		table2Text.setAttribute("class","gx_tbl");
		screenModel.add(table2Text);


	}
	
	/**
	 * Hides the selection menu field
	 * @param screeenModel
	 *      the screen tag model which contains the Selection field
	 */
	public void hideSelectionField(GXIScreenTagModel screeenModel) 
	{

		/** Checks if the field is the selection field */
		GXITag selectionTag;
		try 
		{
			selectionTag = screeenModel.executePositionQuery(22,17);
		} 
		catch //(GXIllegalPositionException e) 
		{
			return;
		}

		if (selectionTag != null)
		{
			selectionTag.setVisible(false,true); // render the tag with: style="display:none"
		}
	}

	public void onComplete(GXRenderEvent e) 
	{
		hideElements(e.getScreenTagModel());
		handleMenuItems(e.getScreenTagModel());
	}

}