using System;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;

	/// <summary>
	/// This class is receiving an "onComplete" event, 
	/// which should be used for manipulating the entire tag model.
	/// </summary>
	public class UserCompletionTransform1 : GXICompletionListener
	{
		public void onComplete(GXRenderEvent e) 
		{
			// Add here code that changes the entire screen tag model. 
			// Use e parameter to access the screen tag model and the host screen.
		}

	}
