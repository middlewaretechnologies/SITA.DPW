using System;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;
using com.sabratec.applinx.baseobject;
using System.IO;
using System.Data;
using com.sabratec.util;
using com.sabratec.applinx.presentation.tags.html;
using System.Xml;
using System.Text;
using com.sabratec.dotnet.framework;
using System.Data.SqlClient;

	/// <summary>
	/// This class is receiving an event on the creation of each type of tag
	/// such as: "onNewlabel", "onNewLabel", "onNewButton", etc. It should be used for tag
	/// level manipulations, such as changing the content and attributes, adding icons, etc.
	/// </summary>
public class WCSMessageTransform : GXTagListener
{
	private string searchInd;
	private string txt;
		
	public override void onNewLabel(GXRenderEvent e, GXILabelTag label)
	{
		// Add here code that handles label fields (Host protected fields).
		// Use e parameter to access the screen tag model and the host screen.
		searchInd = "WCS";
		if (label != null && label.getText().IndexOf(searchInd) >= 0)
		{
			txt = label.getText();
			txt =  txt.Replace("WCS","WIMS");
			label.setText(txt);
		}
		searchInd = "Subject:";
		if (label != null && label.getText().IndexOf(searchInd) >= 0)
		{
			txt = label.getText();
			txt =  txt.Replace("Subject:","");
			label.setText(txt);
		}
		if (label.getId() == "G1_MAPNAME")
		{
			GXHtmlGenericTag messageImg = GXHtmlTagFactory.instance().newGenericTag("img");
			messageImg.setAttribute("src","images/system_ message_button.gif");
			messageImg.setAttribute("id","sysMessage");
			messageImg.setPosition(1,41);
			messageImg.setAttribute("onclick","gx_SubmitKey('[enter]')");
			messageImg.setAttribute("onmouseover","window.status='Enter';return true");
			messageImg.setAttribute("onmouseout","window.status='';return true");

			e.getScreenTagModel().add(messageImg);

		}
		int testlength = label.getId().Trim().Length;
		if (testlength >= 9)
		{
			if (label.getId().Substring(0,9) == "BOODSKAP_")
			{
				label.removeAttribute("style");
				int row = label.getPosition().getRow();
				int column = label.getPosition().getColumn();
				row = row + 4;
				column = column + 9;
				label.setPosition(row,column);
			}
		}

	}
}

