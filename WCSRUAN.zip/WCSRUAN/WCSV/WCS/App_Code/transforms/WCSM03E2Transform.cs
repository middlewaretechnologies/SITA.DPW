using com.sabratec.applinx.baseobject;
using com.sabratec.applinx.presentation;
using com.sabratec.applinx.presentation.queries;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;
using com.sabratec.applinx.presentation.tags.html;
using com.sabratec.util;

	/// <summary>
	/// This class is receiving an "onComplete" event, 
	/// which should be used for manipulating the entire tag model.
	/// </summary>
/**
 * This transformation handles menu screens. It removes unrequired labels from the menu 
 * screen and builds an HTML table with the menu items appearing as links.
 * Handles transformation for the following maps:
 * 
 *			WBSHW1
 */
public class WCSM03E2Transform :GXICompletionListener
{
	/**
	 * Hides elements that are not required to be displayed
	 * @param screenModel
	 *          The screen tag model whose elements should be hidden 
	 */
	private void hideElements(GXIScreenTagModel screenModel)
	{
		/** Executes a query for fields that contain one of the strings and hides them */
		
		GXTextQuery helpQuery = new GXTextQuery("Choice");
		//helpQuery.addSearchText(".");
		//helpQuery.addSearchText("Function");
		//helpQuery.addSearchText("Description");
		//helpQuery.addSearchText("Type");
		//helpQuery.addSearchText("-");
		GXTagList helpList = screenModel.executeQuery(helpQuery);

		for(int i=0;i<helpList.getCount();i++)
		{
			helpList.get(i).setVisible(false);
		}
		/** also hides the Selection text field */
		hideSelectionField(screenModel);
	}
	
	/**
	 * Builds a table with menu items.
	 * Each menu text is created as a table cell.
	 * The menu number is not displayed.
	 * The link activates a JavaScript function <code>placeMenuOption</code> which places the number
	 * within the Selection text field.
	 * The JavaScript function is located in the js/general.js file
	 * @param screenModel
	 *          The screen tag model which should contain the menu items.   
	 */
	private void handleMenuItems(GXIScreenTagModel screenModel)
	{

		GXAreaQuery areaQuery = new GXAreaQuery(8,22);

		GXTagList list = screenModel.executeQuery(areaQuery);
		
		GXITableTag tableText = GXHtmlTagFactory.instance().newTable();
		
		GXITableRowTag trText = null;
		GXITableCellTag tc1Text = null;
		GXITableCellTag tc2Text = null;
		GXITableCellTag tc3Text = null;
		
		trText = GXHtmlTagFactory.instance().newTableRow();
		GXITableCellTag th1Text = GXHtmlTagFactory.instance().newTableCell();
		GXITableCellTag th2Text = GXHtmlTagFactory.instance().newTableCell();
		GXITableCellTag th3Text = GXHtmlTagFactory.instance().newTableCell();
		th1Text.setIsHeader(true);
		th2Text.setIsHeader(true);
		th3Text.setIsHeader(true);
		th1Text.setText("Function");
		th2Text.setText("Description");
		th3Text.setText("Type");
		
		tableText.getRows().add(trText);
		trText.getCells().add(th1Text);
		trText.getCells().add(th2Text);
		trText.getCells().add(th3Text);

		string altRow = "2";
				
		for(int i=0;i<list.getCount();i=i+4)
		{
			tc1Text = GXHtmlTagFactory.instance().newTableCell();
			tc2Text = GXHtmlTagFactory.instance().newTableCell();
			tc3Text = GXHtmlTagFactory.instance().newTableCell();
   
			GXILabelTag currentTag = (GXILabelTag)list.get(i);
			string optionNumber = currentTag.getText().Replace(".","").Trim();

			if (optionNumber != null && optionNumber.Trim().Length > 0)
			{
				try
				{
					/** Checks if the option text is a number */
					int optionNumberInt = System.Int32.Parse(optionNumber);

					if (altRow == "2")
					{
						altRow = "1";
					}
					else
					{
						altRow = "2";
					}
					tc1Text.setText(((GXILabelTag)list.get(i+1)).getText());
					tc1Text.setAttribute("onclick","placeM03E2('" + optionNumber + "')");
					tc1Text.setAttribute("style","width=75px");

					tc2Text.setText(((GXILabelTag)list.get(i+2)).getText());
					tc2Text.setAttribute("onclick","placeM03E2('" + optionNumber + "')");
					tc2Text.setAttribute("style","width=500px");

					tc3Text.setText(((GXILabelTag)list.get(i+3)).getText());
					tc3Text.setAttribute("onclick","placeM020('" + optionNumber + "')");
					tc3Text.setAttribute("style","width=75px; text-align='center'");

					trText = GXHtmlTagFactory.instance().newTableRow();
					trText.setAttribute("class","gx_tbl_alternating" + altRow);
					trText.setAttribute("onmouseover","this.className='helpw_over'");
					trText.setAttribute("onmouseout","this.className='helpw_out" + altRow + "'");
					trText.setAttribute("style","height=20px");
					tableText.getRows().add(trText);
					trText.getCells().add(tc1Text);
					trText.getCells().add(tc2Text);
					trText.getCells().add(tc3Text);
					
					list.get(i).setVisible(false);
					list.get(i+1).setVisible(false);
					list.get(i+2).setVisible(false);
					list.get(i+3).setVisible(false);

				}

				catch //(System.FormatException err)
				{
					/** Ignore when the text without the dot is not a number */
				}
				
			}
		}
		tableText.setPosition(8,9);
		tableText.setAttribute("class","gx_tbl");
		screenModel.add(tableText);
	}
	
	/**
	 * Hides the selection menu field
	 * @param screeenModel
	 *      the screen tag model which contains the Selection field
	 */
	public void hideSelectionField(GXIScreenTagModel screeenModel) 
	{

		/** Checks if the field is the selection field */
		GXITag selectionTag;
		try 
		{
			selectionTag = screeenModel.executePositionQuery(23,45);
		} 
		catch //(GXIllegalPositionException e) 
		{
			return;
		}

		if (selectionTag != null)
		{
			selectionTag.setVisible(false,true); // render the tag with: style="display:none"
		}
	}

	public void onComplete(GXRenderEvent e) 
	{
		hideElements(e.getScreenTagModel());
		handleMenuItems(e.getScreenTagModel());
	}

}