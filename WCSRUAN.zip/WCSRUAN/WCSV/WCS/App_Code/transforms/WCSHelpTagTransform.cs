using System;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;

	/// <summary>
	/// This class is receiving an event on the creation of each type of tag
	/// such as: "onNewTextField", "onNewLabel", "onNewButton", etc. It should be used for tag
	/// level manipulations, such as changing the content and attributes, adding icons, etc.
	/// </summary>
	public class WCSHelpTagTransform : GXTagListener
	{
		private string fieldId;

		public override void onNewLabel(GXRenderEvent e, GXILabelTag label) 
		{
			// Add here code that handles label fields (Host protected fields).
			// Use e parameter to access the screen tag model and the host screen.
			if (label.getId() == "GX_CursorPos")
			{
				fieldId = label.getId();
			}
			fieldId = label.getId();
			fieldId = label.getContent();
			fieldId = label.getTagName();
		}
	}
