using System;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;
using com.sabratec.applinx.baseobject;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using com.sabratec.util;
using com.sabratec.applinx.presentation.tags.html;
using System.Web;
using System.Web.UI;
using System.Web.SessionState;
using System.Configuration;
using java.awt;

/// <summary>
/// This class is receiving an event on the creation of each type of tag
/// such as: "onNewTextField", "onNewLabel", "onNewButton", etc. It should be used for tag
/// level manipulations, such as changing the content and attributes, adding icons, etc.
/// </summary>
public class WCSUserTransform : GXTagListener
{
    public void setLogonId(string userID)
    {
        logonId = userID;
    }

    private string searchInd;
    private string txt;
    private int helpRow;
    private int helpColumn;
    private string helpId;
    private int imgColumn;
    private int lblColumn;
    private string logonId;
    private string alignRight = "N";
    private string radioBtn = "N";
    private string functionInd;
    private string strBtnFunction;
    private string redTest = "N";
    private string timeInd = "I";
    private int redInd;
    private string mapName;
    private string skillsInd = "N";
    private string seqInd;
    private string checkboxInd = "Y";
    private string oneCheckInd = "N";

    public override void onNewLabel(GXRenderEvent e, GXILabelTag label)
    {
        // Add here code that handles label fields (Host protected fields).
        // Use e parameter to access the screen tag model and the host screen.
        searchInd = ".:";
        if (label != null && label.getText().IndexOf(searchInd) >= 0)
        {
            txt = label.getText();
            txt = txt.Replace("..", "");
            txt = txt.Replace(" .", "");
            txt = txt.Replace(".:", ":");
            label.setText(txt);
        }
        string ignoreWCS = "N";
        string choice = "";
        if (null != label && null != label.getId())
            choice = label.getId().Trim();
        switch (choice)
        {
            case "OUDIT_GEBR":
                ignoreWCS = "Y";
                break;
            case "LOG_MAP_USER":
                ignoreWCS = "Y";
                break;
            case "CF_UPD_ID_D":
                ignoreWCS = "Y";
                break;
            case "BYW_ID":
                ignoreWCS = "Y";
                break;
            case "PROJ_LEIER":
                ignoreWCS = "Y";
                break;
            case "KV_BYW_ID":
                ignoreWCS = "Y";
                break;
            case "PROJ_LEIER_KDE_B":
                ignoreWCS = "Y";
                break;
            case "BYW_ID_NAME":
                ignoreWCS = "Y";
                break;
            case "MAGT_AANV_ID":
                ignoreWCS = "Y";
                break;
            case "PROJ_LEIER_KDE":
                ignoreWCS = "Y";
                break;
            case "REG_ID_B":
                ignoreWCS = "Y";
                break;
            case "BYW_ID_B":
                ignoreWCS = "Y";
                break;
            case "FR_ONTV_BYW_ID":
                ignoreWCS = "Y";
                break;
            case "FR_KNTR_BYW_ID":
                ignoreWCS = "Y";
                break;
            case "FR_TEKEN_BYW_ID":
                ignoreWCS = "Y";
                break;
            case "FR_REEL_BYW_ID":
                ignoreWCS = "Y";
                break;
            case "FR_MAAK_BYW_ID":
                ignoreWCS = "Y";
                break;
            case "YR_END_WCS":
                ignoreWCS = "B";
                break;
            case "YR_END_6":
                ignoreWCS = "W";
                break;
            case "YR_END_7":
                ignoreWCS = "C";
                break;
            case "CREATE_BTN":
                ignoreWCS = "R";
                break;
            case "WERKNEMERNO":
                ignoreWCS = "Y";
                break;
            case "REG_ID":
                ignoreWCS = "Y";
                break;
            case "VERIF_ID":
                ignoreWCS = "Y";
                break;
            case "MENTOR_B":
                ignoreWCS = "Y";
                break;
            case "KODE":
                ignoreWCS = "Y";
                break;
            case "BAC_EMAIL_000":
                ignoreWCS = "Y";
                break;
            case "BAC_EMAIL_001":
                ignoreWCS = "Y";
                break;
            case "BAC_EMAIL_002":
                ignoreWCS = "Y";
                break;
            case "BAC_EMAIL_003":
                ignoreWCS = "Y";
                break;
            case "BAC_EMAIL_004":
                ignoreWCS = "Y";
                break;
            case "KDE":
                ignoreWCS = "Y";
                break;
            case "TIME_CHARGE_IND":
                functionInd = "Y";
                break;
            default:
                break;
        }
        if (ignoreWCS == "N")
        {
            if (label != null && label.getId() != null)
            {
                string idx = label.getId().Trim();
                searchInd = "WCS";
                if (label != null && label.getText().IndexOf(searchInd) >= 0)
                {
                    txt = label.getText();
                    txt = txt.Replace("WCS", "WIMS");
                    label.setText(txt);
                }
            }
        }
        if (ignoreWCS == "B")
        {
            searchInd = "WORKS CONTROL SYSTEM (WCS)";
            if (label != null && label.getText().IndexOf(searchInd) >= 0)
            {
                txt = label.getText();
                txt = txt.Replace("WORKS CONTROL SYSTEM (WCS)", "WORKS INFORMATION MANAGEMENT SYSTEM (WIMS) PRODUCTION ENVIRONMENT");
                label.setText(txt);
            }
        }
        if (ignoreWCS == "W")
        {
            searchInd = "The system";
            if (label != null && label.getText().IndexOf(searchInd) >= 0)
            {
                txt = label.getText();
                txt = txt.Replace("The system", "WIMS Production");
                label.setText(txt);
            }
        }
        if (ignoreWCS == "C")
        {
            searchInd = "This session";
            if (label != null && label.getText().IndexOf(searchInd) >= 0)
            {
                txt = label.getText();
                txt = txt.Replace("This session", "Your WIMS Production session");
                label.setText(txt);
            }
        }
        if (ignoreWCS == "R")
        {
            searchInd = "press <PF12>";
            if (label != null && label.getText().IndexOf(searchInd) >= 0)
            {
                txt = label.getText();
                txt = txt.Replace("press <PF12>", "click button");
                label.setText(txt);
            }
        }
        searchInd = "--";
        if (label != null && label.getText().IndexOf(searchInd) >= 0)
        {
            txt = label.getText();
            txt = txt.Replace("--", "__");
            txt = txt.Replace("_-", "__");
            txt = txt.Replace("+", "_");
            txt = txt.Replace("_¦", "__");
            label.setText(txt);
        }
        searchInd = "¦";
        if (label != null && label.getText().IndexOf(searchInd) >= 0)
        {
            txt = label.getText();
            txt = txt.Replace("¦", "");
            label.setText(txt);
        }
        if (label != null && label.getId() != null)
        {
            if (label.getId().Substring(0, 3) == "PF1")
            {
                if (label.getContent() == "*")
                {
                    helpId = label.getId();
                    helpRow = label.getPosition().getRow();
                    helpColumn = label.getPosition().getColumn();
                    helpColumn = helpColumn - 1;
                    label.setPosition(new com.sabratec.util.GXPosition(helpRow, helpColumn));
                    txt = label.getText();
                    txt = txt.Replace("*", "");
                    label.setText(txt);

                    GXHtmlGenericTag helpImg = GXHtmlTagFactory.instance().newGenericTag("input");
                    helpImg.setAttribute("src", "images/help_book.gif");
                    helpImg.setAttribute("class", "helpImg");
                    helpImg.setAttribute("type", "image");
                    helpImg.setAttribute("id", helpId);
                    helpImg.setAttribute("title", "PF1");
                    helpId = helpId.Replace("PF1_", "");
                    helpImg.setAttribute("onclick", "gx_SubmitKeyInPos('" + helpId + "','[pf1]')");
                    helpImg.setAttribute("onmouseover", "window.status='PF1';return true");
                    helpImg.setAttribute("onmouseout", "window.status='';return true");

                    e.getScreenTagModel().replace(label, helpImg);
                }
            }
        }
        if (label != null && label.getId() != null)
        {
            if (label.getId().Substring(0, 3) == "PFV")
            {
                if (label.getContent() == "*")
                {
                    helpId = label.getId();
                    helpRow = label.getPosition().getRow();
                    helpColumn = label.getPosition().getColumn();
                    helpColumn = helpColumn - 1;
                    label.setPosition(new com.sabratec.util.GXPosition(helpRow, helpColumn));
                    txt = label.getText();
                    txt = txt.Replace("*", "");
                    label.setText(txt);

                    GXHtmlGenericTag helpImg = GXHtmlTagFactory.instance().newGenericTag("input");
                    helpImg.setAttribute("src", "images/help_book.gif");
                    helpImg.setAttribute("class", "helpImg");
                    helpImg.setAttribute("type", "image");
                    helpImg.setAttribute("id", helpId);
                    helpImg.setAttribute("title", "PF1");
                    helpId = helpId.Replace("PFV_", "");
                    helpImg.setAttribute("onclick", "gx_SubmitKeyInPos('" + helpId + "','[pf1]')");
                    helpImg.setAttribute("onmouseover", "window.status='PF1';return true");
                    helpImg.setAttribute("onmouseout", "window.status='';return true");

                    e.getScreenTagModel().replace(label, helpImg);
                }
            }
        }
        if (label != null && label.getId() != null)
        {
            if (label.getId().Substring(0, 3) == "PFT")
            {
                helpId = label.getId();
                helpRow = label.getPosition().getRow();
                helpColumn = label.getPosition().getColumn();
                helpColumn = helpColumn - 1;
                label.setPosition(new com.sabratec.util.GXPosition(helpRow, helpColumn));
                txt = label.getText();
                txt = txt.Replace("*", "");
                label.setText(txt);

                GXHtmlGenericTag helpImg = GXHtmlTagFactory.instance().newGenericTag("input");
                helpImg.setAttribute("src", "images/help_book.gif");
                helpImg.setAttribute("class", "helpImg");
                helpImg.setAttribute("type", "image");
                helpImg.setAttribute("id", helpId);
                helpImg.setAttribute("title", "PF1");
                helpId = helpId.Replace("PFT_", "");
                helpImg.setAttribute("onclick", "gx_SubmitKeyInPos('" + helpId + "','[pf1]')");
                helpImg.setAttribute("onmouseover", "window.status='PF1';return true");
                helpImg.setAttribute("onmouseout", "window.status='';return true");

                e.getScreenTagModel().replace(label, helpImg);
            }
        }
        if (label != null && label.getId() != null)
        {
            if (label.getId().Substring(0, 3) == "PF_")
            {
                helpId = label.getId();
                helpRow = label.getPosition().getRow();
                helpColumn = label.getPosition().getColumn();
                if (helpColumn > 1)
                {
                    helpColumn = helpColumn - 1;
                }
                label.setPosition(new com.sabratec.util.GXPosition(helpRow, helpColumn));

                GXHtmlGenericTag helpImg = GXHtmlTagFactory.instance().newGenericTag("input");
                helpImg.setAttribute("src", "images/help_green.gif");
                helpImg.setAttribute("class", "helpImg");
                helpImg.setAttribute("type", "image");
                helpImg.setAttribute("id", helpId);
                helpImg.setAttribute("title", "PF10");
                helpId = helpId.Replace("PF_", "");
                helpImg.setAttribute("onclick", "gx_SubmitKeyInPos('" + helpId + "','[pf10]')");
                helpImg.setAttribute("onmouseover", "window.status='PF1';return true");
                helpImg.setAttribute("onmouseout", "window.status='';return true");

                e.getScreenTagModel().replace(label, helpImg);
            }
        }
        if (label != null && label.getId() != null)
        {
            if (label.getId().Substring(0, 3) == "PFE")
            {
                helpId = label.getId();
                helpRow = label.getPosition().getRow();
                helpColumn = label.getPosition().getColumn();
                if (helpColumn > 1)
                {
                    helpColumn = helpColumn - 1;
                }
                label.setPosition(new com.sabratec.util.GXPosition(helpRow, helpColumn));

                GXHtmlGenericTag helpImg = GXHtmlTagFactory.instance().newGenericTag("input");
                helpImg.setAttribute("src", "images/help_green.gif");
                helpImg.setAttribute("class", "helpImg");
                helpImg.setAttribute("type", "image");
                helpImg.setAttribute("id", helpId);
                helpImg.setAttribute("title", "enter");
                helpId = helpId.Replace("PFE_", "");
                helpImg.setAttribute("onclick", "gx_SubmitKeyInPos('" + helpId + "','[enter]')");
                helpImg.setAttribute("onmouseover", "window.status='Enter';return true");
                helpImg.setAttribute("onmouseout", "window.status='';return true");

                e.getScreenTagModel().replace(label, helpImg);
            }
        }
        if (label != null && label.getId() != null)
        {
            if (label.getId().Trim().Length > 8)
            {
                if (label.getId().Substring(0, 8) == "SUB_SEQ_")
                {
                    seqInd = label.getContent().Trim();
                }
            }
        }
        if (label != null && label.getId() != null)
        {
            if (label.getId().Trim().Length > 4)
            {
                if (label.getId().Substring(0, 4) == "SEQ_")
                {
                    seqInd = label.getContent().Trim();
                }
            }
        }
        if (label != null && label.getId() != null)
        {
            if (label.getId().Trim() == "AVERAGE_HEADING")
            {
                if (label.getContent().Trim() == "Average")
                {
                    checkboxInd = "N";
                }
            }
        }
        if (label != null && label.getId() != null)
        {
            if (label.getId().Trim() == "SKILLS")
            {
                if (label.getContent().Trim() == "Skills Achieved")
                {
                    oneCheckInd = "Y";
                }
            }
        }
        if (label != null && label.getId() != null)
        {
            if (label.getId().Trim().Length > 7)
            {
                if (label.getId().Substring(0, 7) == "RATING_")
                {
                    if (checkboxInd == "Y")
                    {
                        if (seqInd != "")
                        {
                            int radioRow = 0;
                            int radioColumn = 0;
                            int radioIndex = Convert.ToInt32(label.getId().Substring(7, 3));
                            GXIField inputTag = e.getHostScreen().getFieldInstance("RATING", radioIndex);
                            radioRow = label.getPosition().getRow();
                            radioColumn = label.getPosition().getColumn();
                            GXHtmlGenericTag radioImg = GXHtmlTagFactory.instance().newGenericTag("input");
                            radioImg.setAttribute("type", "checkbox");
                            radioImg.setAttribute("id", "cmdCheckBox");
                            radioImg.setAttribute("value", label.getId().Trim());
                            radioImg.setAttribute("name", "cmdCheckBox");
                            radioImg.setAttribute("style", "POSITION: absolute!");
                            radioImg.setAttribute("disabled", "true");
                            radioImg.setPosition(radioRow, radioColumn);
                            if (inputTag.getContent().Trim() == "X")
                            {
                                radioImg.setAttribute("Checked", "true");
                            }
                            if (oneCheckInd == "Y")
                            {
                                if (radioIndex == 2 || radioIndex == 7 || radioIndex == 12 || radioIndex == 17 ||
                                    radioIndex == 22 || radioIndex == 27 || radioIndex == 32 || radioIndex == 37 ||
                                    radioIndex == 42 || radioIndex == 57 || radioIndex == 52 || radioIndex == 57 ||
                                    radioIndex == 62)
                                {
                                    e.getScreenTagModel().add(radioImg);
                                }
                            }
                            else
                            {
                                e.getScreenTagModel().add(radioImg);
                            }
                        }
                    }
                }
            }
        }
        if (label != null && label.getId() != null)
        {
            if (label.getId() == "G1_MAPNAME")
            {
                mapName = label.getText().Trim();
                if (label.getText().Trim() == "WK03PUE2" || label.getText().Trim() == "WK03PUE3" || label.getText().Trim() == "WK03PUE5")
                {
                    strBtnFunction = label.getContent().Substring(0, 8).Trim();
                    functionInd = "N";
                    redTest = "Y";
                }
                else
                {
                    if (label.getText().Trim() == "XMAS")
                    {
                        functionInd = "N";
                        GXHtmlGenericTag xmasImg = GXHtmlTagFactory.instance().newGenericTag("img");
                        xmasImg.setAttribute("src", "images/XMAS1.jpg");
                        xmasImg.setAttribute("class", "xmasImg");
                        e.getScreenTagModel().add(xmasImg);
                    }
                    else
                    {
                        if (label.getText().Trim() == "WI01PUE5")
                        {
                            functionInd = "N";
                            GXHtmlGenericTag stopImg = GXHtmlTagFactory.instance().newGenericTag("img");
                            stopImg.setAttribute("src", "images/sort_icon.gif");
                            stopImg.setAttribute("class", "stopImg");
                            e.getScreenTagModel().add(stopImg);
                        }
                        else
                        {
                            strBtnFunction = label.getContent().Substring(0, 8).Trim();
                            functionInd = "Y";
                        }
                    }
                }
            }
        }
        if (functionInd == "Y")
        {
            functionInd = "N";
            if (strBtnFunction == "IS0001E5" || strBtnFunction == "IS0001E6" || strBtnFunction == "IS0001E9"
                || strBtnFunction == "IS0008WE")
            {
                GXHtmlGenericTag sorryImg = GXHtmlTagFactory.instance().newGenericTag("img");
                sorryImg.setAttribute("src", "images/sorry.jpg");
                if (strBtnFunction == "IS0008WE")
                {
                    sorryImg.setAttribute("class", "sorryImg");
                }
                else
                {
                    if (strBtnFunction == "IS0001E9")
                    {
                        sorryImg.setAttribute("class", "sorryDev");
                    }
                    else
                    {
                        sorryImg.setAttribute("class", "sorryOff");
                    }
                }
                e.getScreenTagModel().add(sorryImg);
            }
            if (strBtnFunction == "IS0001E7")
            {
                GXHtmlGenericTag reminderImg = GXHtmlTagFactory.instance().newGenericTag("img");
                reminderImg.setAttribute("src", "images/reminder_clock.gif");
                reminderImg.setAttribute("class", "reminderOff");
                e.getScreenTagModel().add(reminderImg);
            }
            if (strBtnFunction.Trim() == "WA22PEE1" || strBtnFunction == "WM49PEE1" || strBtnFunction == "WM48PUE1"
                || strBtnFunction == "WM40PEE1" || strBtnFunction == "WL05PEE1" || strBtnFunction == "WA20PEE1"
                || strBtnFunction == "WH01PUE3" || strBtnFunction == "WI01PUE3" || strBtnFunction == "WK12PEE1"
                || strBtnFunction == "WL13PEE1" || strBtnFunction == "WG30PUE2" || strBtnFunction == "WG30PUE3"
                || strBtnFunction == "WG30PUE4" || strBtnFunction == "WG31PEE4" || strBtnFunction == "WG31PEE2"
                || strBtnFunction == "WG31PEE3" || strBtnFunction == "WG34PEE1" || strBtnFunction == "WM39PUE1"
                || strBtnFunction == "WM41PUE1" || strBtnFunction == "WM50PUE1" || strBtnFunction == "WM53PDE1"
                || strBtnFunction == "WM54PDE1" || strBtnFunction == "WG27PEE3" || strBtnFunction == "WG27PEE5"
                || strBtnFunction == "WG26PUE7" || strBtnFunction == "WG27PEE6" || strBtnFunction == "WG27PEE4"
                || strBtnFunction == "WG26PUE4" || strBtnFunction == "WM58PEE1" || strBtnFunction == "WA31PUE1"
                || strBtnFunction == "WA16PEE3" || strBtnFunction == "WA33PUE1" || strBtnFunction == "WA34PEE1")
            {
                GXILabelTag rowLbl1 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl2 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl3 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl4 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl5 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl6 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl7 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl8 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl9 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl10 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl11 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl12 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl13 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl14 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl15 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl16 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl17 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl18 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl19 = GXHtmlTagFactory.instance().newLabel("");
                GXILabelTag rowLbl20 = GXHtmlTagFactory.instance().newLabel("");

                switch (strBtnFunction)
                {
                    case "WL05PEE1":
                        rowLbl1.setAttribute("class", "WL05PE_Label1");
                        rowLbl2.setAttribute("class", "WL05PE_Label2");
                        rowLbl3.setAttribute("class", "WL05PE_Label3");
                        rowLbl4.setAttribute("class", "WL05PE_Label4");
                        rowLbl5.setAttribute("class", "WL05PE_Label5");
                        rowLbl6.setAttribute("class", "WL05PE_Label6");
                        rowLbl7.setAttribute("class", "WL05PE_Label7");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);

                        radioBtn = "Y";
                        break;

                    case "WA22PEE1":
                        rowLbl1.setAttribute("class", "WA22PE_Label1");
                        rowLbl2.setAttribute("class", "WA22PE_Label2");
                        rowLbl3.setAttribute("class", "WA22PE_Label3");
                        rowLbl4.setAttribute("class", "WA22PE_Label4");
                        rowLbl5.setAttribute("class", "WA22PE_Label5");
                        rowLbl6.setAttribute("class", "WA22PE_Label6");
                        rowLbl7.setAttribute("class", "WA22PE_Label7");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);
                        break;

                    case "WA20PEE1":
                        rowLbl1.setAttribute("class", "WA20PE_Label1");
                        rowLbl2.setAttribute("class", "WA20PE_Label2");
                        rowLbl3.setAttribute("class", "WA20PE_Label3");
                        rowLbl4.setAttribute("class", "WA20PE_Label4");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);

                        radioBtn = "Y";
                        break;

                    case "WA31PUE1":
                        rowLbl1.setAttribute("class", "WA31_Label1");
                        rowLbl2.setAttribute("class", "WA31_Label2");
                        rowLbl3.setAttribute("class", "WA31_Label3");
                        rowLbl4.setAttribute("class", "WA31_Label4");
                        rowLbl5.setAttribute("class", "WA31_Label5");
                        rowLbl6.setAttribute("class", "WA31_Label6");
                        rowLbl7.setAttribute("class", "WA31_Label7");
                        rowLbl8.setAttribute("class", "WA31_Label8");
                        rowLbl9.setAttribute("class", "WA31_Label9");
                        rowLbl10.setAttribute("class", "WA31_Label10");
                        rowLbl11.setAttribute("class", "WA31_Label11");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);
                        e.getScreenTagModel().add(rowLbl8);
                        e.getScreenTagModel().add(rowLbl9);
                        e.getScreenTagModel().add(rowLbl10);
                        e.getScreenTagModel().add(rowLbl11);

                        break;
                    case "WA16PEE3":
                        rowLbl1.setAttribute("class", "WA16_Label1");
                        rowLbl2.setAttribute("class", "WA16_Label2");
                        rowLbl3.setAttribute("class", "WA16_Label3");
                        rowLbl4.setAttribute("class", "WA16_Label4");
                        rowLbl5.setAttribute("class", "WA16_Label5");
                        rowLbl6.setAttribute("class", "WA16_Label6");
                        rowLbl7.setAttribute("class", "WA16_Label7");
                        rowLbl8.setAttribute("class", "WA16_Label8");
                        rowLbl9.setAttribute("class", "WA16_Label9");
                        rowLbl10.setAttribute("class", "WA16_Label10");
                        rowLbl11.setAttribute("class", "WA16_Label11");
                        rowLbl12.setAttribute("class", "WA16_Label12");
                        rowLbl13.setAttribute("class", "WA16_Label13");
                        rowLbl14.setAttribute("class", "WA16_Label14");
                        rowLbl15.setAttribute("class", "WA16_Label15");
                        rowLbl16.setAttribute("class", "WA16_Label16");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);
                        e.getScreenTagModel().add(rowLbl8);
                        e.getScreenTagModel().add(rowLbl9);
                        e.getScreenTagModel().add(rowLbl10);
                        e.getScreenTagModel().add(rowLbl11);
                        e.getScreenTagModel().add(rowLbl12);
                        e.getScreenTagModel().add(rowLbl13);
                        e.getScreenTagModel().add(rowLbl14);
                        e.getScreenTagModel().add(rowLbl15);
                        e.getScreenTagModel().add(rowLbl16);
                        break;

                    case "WA34PEE1":
                        rowLbl1.setAttribute("class", "WA34_Label1");
                        rowLbl2.setAttribute("class", "WA34_Label2");
                        rowLbl3.setAttribute("class", "WA34_Label3");
                        rowLbl4.setAttribute("class", "WA34_Label4");
                        rowLbl5.setAttribute("class", "WA34_Label5");
                        rowLbl6.setAttribute("class", "WA34_Label6");
                        rowLbl7.setAttribute("class", "WA34_Label7");
                        rowLbl8.setAttribute("class", "WA34_Label8");
                        rowLbl9.setAttribute("class", "WA34_Label9");
                        rowLbl10.setAttribute("class", "WA34_Label10");
                        rowLbl11.setAttribute("class", "WA34_Label11");
                        rowLbl12.setAttribute("class", "WA34_Label12");
                        rowLbl13.setAttribute("class", "WA34_Label13");
                        rowLbl14.setAttribute("class", "WA34_Label14");
                        rowLbl15.setAttribute("class", "WA34_Label15");
                        rowLbl16.setAttribute("class", "WA34_Label16");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);
                        e.getScreenTagModel().add(rowLbl8);
                        e.getScreenTagModel().add(rowLbl9);
                        e.getScreenTagModel().add(rowLbl10);
                        e.getScreenTagModel().add(rowLbl11);
                        e.getScreenTagModel().add(rowLbl12);
                        e.getScreenTagModel().add(rowLbl13);
                        e.getScreenTagModel().add(rowLbl14);
                        e.getScreenTagModel().add(rowLbl15);
                        e.getScreenTagModel().add(rowLbl16);

                        break;

                    case "WA33PUE1":
                        rowLbl1.setAttribute("class", "WA33_Label1");
                        rowLbl2.setAttribute("class", "WA33_Label2");
                        rowLbl3.setAttribute("class", "WA33_Label3");
                        rowLbl4.setAttribute("class", "WA33_Label4");
                        rowLbl5.setAttribute("class", "WA33_Label5");
                        rowLbl6.setAttribute("class", "WA33_Label6");
                        rowLbl7.setAttribute("class", "WA33_Label7");
                        rowLbl8.setAttribute("class", "WA33_Label8");
                        rowLbl9.setAttribute("class", "WA33_Label9");
                        rowLbl10.setAttribute("class", "WA33_Label10");
                        rowLbl11.setAttribute("class", "WA33_Label11");
                        rowLbl12.setAttribute("class", "WA33_Label12");
                        rowLbl13.setAttribute("class", "WA33_Label13");
                        rowLbl14.setAttribute("class", "WA33_Label14");
                        rowLbl15.setAttribute("class", "WA33_Label15");
                        rowLbl16.setAttribute("class", "WA33_Label16");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);
                        e.getScreenTagModel().add(rowLbl8);
                        e.getScreenTagModel().add(rowLbl9);
                        e.getScreenTagModel().add(rowLbl10);
                        e.getScreenTagModel().add(rowLbl11);
                        e.getScreenTagModel().add(rowLbl12);
                        e.getScreenTagModel().add(rowLbl13);
                        e.getScreenTagModel().add(rowLbl14);
                        e.getScreenTagModel().add(rowLbl15);
                        e.getScreenTagModel().add(rowLbl16);

                        break;

                    case "WK12PEE1":
                        rowLbl1.setAttribute("class", "WK12PE_Label1");
                        rowLbl2.setAttribute("class", "WK12PE_Label2");
                        rowLbl3.setAttribute("class", "WK12PE_Label3");
                        rowLbl4.setAttribute("class", "WK12PE_Label4");
                        rowLbl5.setAttribute("class", "WK12PE_Label5");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);

                        radioBtn = "Y";
                        break;

                    case "WG26PUE4":
                        goto case "WG27PEE4";

                    case "WG27PEE4":
                        rowLbl1.setAttribute("class", "WG26_4_Label1");
                        rowLbl2.setAttribute("class", "WG26_4_Label2");
                        rowLbl3.setAttribute("class", "WG26_4_Label3");
                        rowLbl4.setAttribute("class", "WG26_4_Label4");
                        rowLbl5.setAttribute("class", "WG26_4_Label5");
                        rowLbl6.setAttribute("class", "WG26_4_Label6");
                        rowLbl7.setAttribute("class", "WG26_4_Label7");
                        rowLbl8.setAttribute("class", "WG26_4_Label8");
                        rowLbl9.setAttribute("class", "WG26_4_Label9");
                        rowLbl10.setAttribute("class", "WG26_4_Label10");
                        rowLbl11.setAttribute("class", "WG26_4_Label11");
                        rowLbl12.setAttribute("class", "WG26_4_Label12");
                        rowLbl13.setAttribute("class", "WG26_4_Label13");
                        rowLbl14.setAttribute("class", "WG26_4_Label14");
                        rowLbl15.setAttribute("class", "WG26_4_Label15");
                        rowLbl16.setAttribute("class", "WG26_4_Label16");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);
                        e.getScreenTagModel().add(rowLbl8);
                        e.getScreenTagModel().add(rowLbl9);
                        e.getScreenTagModel().add(rowLbl10);
                        e.getScreenTagModel().add(rowLbl11);
                        e.getScreenTagModel().add(rowLbl12);
                        e.getScreenTagModel().add(rowLbl13);
                        e.getScreenTagModel().add(rowLbl14);
                        e.getScreenTagModel().add(rowLbl15);
                        e.getScreenTagModel().add(rowLbl16);

                        break;

                    case "WG27PEE3":
                        goto case "WG34PEE1";

                    case "WG27PEE5":
                        goto case "WG34PEE1";

                    case "WG27PEE6":
                        goto case "WG26PUE7";

                    case "WG26PUE7":
                        rowLbl1.setAttribute("class", "WG26_Label1");
                        rowLbl2.setAttribute("class", "WG26_Label2");
                        rowLbl3.setAttribute("class", "WG26_Label3");
                        rowLbl4.setAttribute("class", "WG26_Label4");
                        rowLbl5.setAttribute("class", "WG26_Label5");
                        rowLbl6.setAttribute("class", "WG26_Label6");
                        rowLbl7.setAttribute("class", "WG26_Label7");
                        rowLbl8.setAttribute("class", "WG26_Label8");
                        rowLbl9.setAttribute("class", "WG26_Label9");
                        rowLbl10.setAttribute("class", "WG26_Label10");
                        rowLbl11.setAttribute("class", "WG26_Label11");
                        rowLbl12.setAttribute("class", "WG26_Label12");
                        rowLbl13.setAttribute("class", "WG26_Label13");
                        rowLbl14.setAttribute("class", "WG26_Label14");
                        rowLbl15.setAttribute("class", "WG26_Label15");
                        rowLbl16.setAttribute("class", "WG26_Label16");
                        rowLbl17.setAttribute("class", "WG26_Label17");
                        rowLbl18.setAttribute("class", "WG26_Label18");
                        rowLbl19.setAttribute("class", "WG26_Label19");
                        rowLbl20.setAttribute("class", "WG26_Label20");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);
                        e.getScreenTagModel().add(rowLbl8);
                        e.getScreenTagModel().add(rowLbl9);
                        e.getScreenTagModel().add(rowLbl10);
                        e.getScreenTagModel().add(rowLbl11);
                        e.getScreenTagModel().add(rowLbl12);
                        e.getScreenTagModel().add(rowLbl13);
                        e.getScreenTagModel().add(rowLbl14);
                        e.getScreenTagModel().add(rowLbl15);
                        e.getScreenTagModel().add(rowLbl16);
                        e.getScreenTagModel().add(rowLbl17);
                        e.getScreenTagModel().add(rowLbl18);
                        e.getScreenTagModel().add(rowLbl19);
                        e.getScreenTagModel().add(rowLbl20);

                        break;

                    case "WG30PUE4":
                        goto case "WG31PEE4";

                    case "WG31PEE4":
                        rowLbl1.setAttribute("class", "WG_Label1");
                        rowLbl2.setAttribute("class", "WG_Label2");
                        rowLbl3.setAttribute("class", "WG_Label3");
                        rowLbl4.setAttribute("class", "WG_Label4");
                        rowLbl5.setAttribute("class", "WG_Label5");
                        rowLbl6.setAttribute("class", "WG_Label6");
                        rowLbl7.setAttribute("class", "WG_Label7");
                        rowLbl8.setAttribute("class", "WG_Label8");
                        rowLbl9.setAttribute("class", "WG_Label9");
                        rowLbl10.setAttribute("class", "WG_Label10");
                        rowLbl11.setAttribute("class", "WG_Label11");
                        rowLbl12.setAttribute("class", "WG_Label12");
                        rowLbl13.setAttribute("class", "WG_Label13");
                        rowLbl14.setAttribute("class", "WG_Label14");
                        rowLbl15.setAttribute("class", "WG_Label15");
                        rowLbl16.setAttribute("class", "WG_Label16");
                        rowLbl17.setAttribute("class", "WG_Label17");
                        rowLbl18.setAttribute("class", "WG_Label18");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);
                        e.getScreenTagModel().add(rowLbl8);
                        e.getScreenTagModel().add(rowLbl9);
                        e.getScreenTagModel().add(rowLbl10);
                        e.getScreenTagModel().add(rowLbl11);
                        e.getScreenTagModel().add(rowLbl12);
                        e.getScreenTagModel().add(rowLbl13);
                        e.getScreenTagModel().add(rowLbl14);
                        e.getScreenTagModel().add(rowLbl15);
                        e.getScreenTagModel().add(rowLbl16);
                        e.getScreenTagModel().add(rowLbl17);
                        e.getScreenTagModel().add(rowLbl18);

                        break;

                    case "WG31PEE3":
                        goto case "WG30PUE3";

                    case "WG30PUE3":
                        rowLbl1.setAttribute("class", "WG3_Label1");
                        rowLbl2.setAttribute("class", "WG3_Label2");
                        rowLbl3.setAttribute("class", "WG3_Label3");
                        rowLbl4.setAttribute("class", "WG3_Label4");
                        rowLbl5.setAttribute("class", "WG3_Label5");
                        rowLbl6.setAttribute("class", "WG3_Label6");
                        rowLbl7.setAttribute("class", "WG3_Label7");
                        rowLbl8.setAttribute("class", "WG3_Label8");
                        rowLbl9.setAttribute("class", "WG3_Label9");
                        rowLbl10.setAttribute("class", "WG3_Label10");
                        rowLbl11.setAttribute("class", "WG3_Label11");
                        rowLbl12.setAttribute("class", "WG3_Label12");
                        rowLbl13.setAttribute("class", "WG3_Label13");
                        rowLbl14.setAttribute("class", "WG3_Label14");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);
                        e.getScreenTagModel().add(rowLbl8);
                        e.getScreenTagModel().add(rowLbl9);
                        e.getScreenTagModel().add(rowLbl10);
                        e.getScreenTagModel().add(rowLbl11);
                        e.getScreenTagModel().add(rowLbl12);
                        e.getScreenTagModel().add(rowLbl13);
                        e.getScreenTagModel().add(rowLbl14);

                        break;

                    case "WG31PEE2":
                        goto case "WG30PUE2";

                    case "WG30PUE2":
                        rowLbl1.setAttribute("class", "WG2_Label1");
                        rowLbl2.setAttribute("class", "WG2_Label2");
                        rowLbl3.setAttribute("class", "WG2_Label3");
                        rowLbl4.setAttribute("class", "WG2_Label4");
                        rowLbl5.setAttribute("class", "WG2_Label5");
                        rowLbl6.setAttribute("class", "WG2_Label6");
                        rowLbl7.setAttribute("class", "WG2_Label7");
                        rowLbl8.setAttribute("class", "WG2_Label8");
                        rowLbl9.setAttribute("class", "WG2_Label9");
                        rowLbl10.setAttribute("class", "WG2_Label10");
                        rowLbl11.setAttribute("class", "WG2_Label11");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);
                        e.getScreenTagModel().add(rowLbl8);
                        e.getScreenTagModel().add(rowLbl9);
                        e.getScreenTagModel().add(rowLbl10);
                        e.getScreenTagModel().add(rowLbl11);

                        break;

                    case "WG34PEE1":
                        rowLbl1.setAttribute("class", "WG34PEE1_Label1");
                        rowLbl2.setAttribute("class", "WG34PEE1_Label2");
                        rowLbl3.setAttribute("class", "WG34PEE1_Label3");
                        rowLbl4.setAttribute("class", "WG34PEE1_Label4");
                        rowLbl5.setAttribute("class", "WG34PEE1_Label5");
                        rowLbl6.setAttribute("class", "WG34PEE1_Label6");
                        rowLbl7.setAttribute("class", "WG34PEE1_Label7");
                        rowLbl8.setAttribute("class", "WG34PEE1_Label8");
                        rowLbl9.setAttribute("class", "WG34PEE1_Label9");
                        rowLbl10.setAttribute("class", "WG34PEE1_Label10");
                        rowLbl11.setAttribute("class", "WG34PEE1_Label11");
                        rowLbl12.setAttribute("class", "WG34PEE1_Label12");
                        rowLbl13.setAttribute("class", "WG34PEE1_Label13");
                        rowLbl14.setAttribute("class", "WG34PEE1_Label14");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);
                        e.getScreenTagModel().add(rowLbl8);
                        e.getScreenTagModel().add(rowLbl9);
                        e.getScreenTagModel().add(rowLbl10);
                        e.getScreenTagModel().add(rowLbl11);
                        e.getScreenTagModel().add(rowLbl12);
                        e.getScreenTagModel().add(rowLbl13);
                        e.getScreenTagModel().add(rowLbl14);

                        break;

                    case "WH01PUE3":
                        rowLbl1.setAttribute("class", "WH_Label1");
                        rowLbl2.setAttribute("class", "WH_Label2");
                        rowLbl3.setAttribute("class", "WH_Label3");
                        rowLbl4.setAttribute("class", "WH_Label4");
                        rowLbl5.setAttribute("class", "WH_Label5");
                        /*rowLbl6.setAttribute("class","WH_Label6");*/

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        /*e.getScreenTagModel().add(rowLbl6);*/

                        radioBtn = "Y";

                        break;

                    case "WI01PUE3":
                        rowLbl1.setAttribute("class", "WI_Label1");
                        rowLbl2.setAttribute("class", "WI_Label2");
                        rowLbl3.setAttribute("class", "WI_Label3");
                        rowLbl4.setAttribute("class", "WI_Label4");
                        rowLbl5.setAttribute("class", "WI_Label5");
                        /*rowLbl6.setAttribute("class","WI_Label6");
						rowLbl7.setAttribute("class","WI_Label7");
						rowLbl8.setAttribute("class","WI_Label8");*/

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        /*e.getScreenTagModel().add(rowLbl7);
						e.getScreenTagModel().add(rowLbl8);*/

                        radioBtn = "Y";

                        break;

                    case "WL13PEE1":
                        rowLbl1.setAttribute("class", "WL13PE_Label1");
                        rowLbl2.setAttribute("class", "WL13PE_Label2");
                        rowLbl3.setAttribute("class", "WL13PE_Label3");
                        rowLbl4.setAttribute("class", "WL13PE_Label4");
                        rowLbl5.setAttribute("class", "WL13PE_Label5");
                        rowLbl6.setAttribute("class", "WL13PE_Label6");
                        rowLbl7.setAttribute("class", "WL13PE_Label7");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);

                        radioBtn = "Y";
                        break;

                    case "WM50PUE1":
                        goto case "WM41PUE1";

                    case "WM41PUE1":
                        rowLbl1.setAttribute("class", "WMV_Label1");
                        rowLbl2.setAttribute("class", "WMV_Label2");
                        rowLbl3.setAttribute("class", "WMV_Label3");
                        rowLbl4.setAttribute("class", "WMV_Label4");
                        rowLbl5.setAttribute("class", "WMV_Label5");
                        rowLbl6.setAttribute("class", "WMV_Label6");
                        rowLbl7.setAttribute("class", "WMV_Label7");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);

                        break;

                    case "WM39PUE1":
                        goto case "WM48PUE1";

                    case "WM48PUE1":
                        rowLbl1.setAttribute("class", "WM_Label1");
                        rowLbl2.setAttribute("class", "WM_Label2");
                        rowLbl3.setAttribute("class", "WM_Label3");
                        rowLbl4.setAttribute("class", "WM_Label4");
                        rowLbl5.setAttribute("class", "WM_Label5");
                        rowLbl6.setAttribute("class", "WM_Label6");
                        rowLbl7.setAttribute("class", "WM_Label7");
                        rowLbl8.setAttribute("class", "WM_Label8");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);
                        e.getScreenTagModel().add(rowLbl8);

                        break;

                    case "WM58PEE1":
                        rowLbl1.setAttribute("class", "WM58_Label1");
                        rowLbl2.setAttribute("class", "WM58_Label2");
                        rowLbl3.setAttribute("class", "WM58_Label3");
                        rowLbl4.setAttribute("class", "WM58_Label4");
                        rowLbl5.setAttribute("class", "WM58_Label5");
                        rowLbl6.setAttribute("class", "WM58_Label6");
                        rowLbl7.setAttribute("class", "WM58_Label7");
                        rowLbl8.setAttribute("class", "WM58_Label8");
                        rowLbl9.setAttribute("class", "WM58_Label9");
                        rowLbl10.setAttribute("class", "WM58_Label10");
                        rowLbl11.setAttribute("class", "WM58_Label11");
                        rowLbl12.setAttribute("class", "WM58_Label12");
                        rowLbl13.setAttribute("class", "WM58_Label13");
                        rowLbl14.setAttribute("class", "WM58_Label14");
                        rowLbl15.setAttribute("class", "WM58_Label15");
                        rowLbl16.setAttribute("class", "WM58_Label16");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);
                        e.getScreenTagModel().add(rowLbl8);
                        e.getScreenTagModel().add(rowLbl9);
                        e.getScreenTagModel().add(rowLbl10);
                        e.getScreenTagModel().add(rowLbl11);
                        e.getScreenTagModel().add(rowLbl12);
                        e.getScreenTagModel().add(rowLbl13);
                        e.getScreenTagModel().add(rowLbl14);
                        e.getScreenTagModel().add(rowLbl15);
                        e.getScreenTagModel().add(rowLbl16);

                        break;

                    default:
                        rowLbl1.setAttribute("class", "WME_Label1");
                        rowLbl2.setAttribute("class", "WME_Label2");
                        rowLbl3.setAttribute("class", "WME_Label3");
                        rowLbl4.setAttribute("class", "WME_Label4");
                        rowLbl5.setAttribute("class", "WME_Label5");
                        rowLbl6.setAttribute("class", "WME_Label6");
                        rowLbl7.setAttribute("class", "WME_Label7");
                        rowLbl8.setAttribute("class", "WME_Label8");

                        e.getScreenTagModel().add(rowLbl1);
                        e.getScreenTagModel().add(rowLbl2);
                        e.getScreenTagModel().add(rowLbl3);
                        e.getScreenTagModel().add(rowLbl4);
                        e.getScreenTagModel().add(rowLbl5);
                        e.getScreenTagModel().add(rowLbl6);
                        e.getScreenTagModel().add(rowLbl7);
                        e.getScreenTagModel().add(rowLbl8);

                        break;
                }
            }

            string strBtnConn = ConfigurationSettings.AppSettings["conWCSFunc"];
            SqlConnection connBtnFunc = new SqlConnection(strBtnConn);
            connBtnFunc.Open();

            SqlCommand cmdNoFunction = new SqlCommand("spReadNoFunctionMap", connBtnFunc);
            cmdNoFunction.CommandType = CommandType.StoredProcedure;
            SqlParameter parmNoFunction = cmdNoFunction.Parameters.Add("@parmMapName", SqlDbType.VarChar, 8);
            parmNoFunction.Direction = ParameterDirection.Input;
            parmNoFunction.Value = strBtnFunction;
            SqlDataReader drNoFunction = cmdNoFunction.ExecuteReader();

            if (drNoFunction.HasRows == true)
            {
                drNoFunction.Close();
            }
            else
            {
                drNoFunction.Close();

                string ignoreInd = "N";
                searchInd = "WBS";
                if (strBtnFunction.IndexOf(searchInd) >= 0)
                {
                    ignoreInd = "Y";
                }
                switch (strBtnFunction)
                {
                    case "WBSMANE1":
                        ignoreInd = "N";
                        break;
                    case "WBSP04E1":
                        ignoreInd = "N";
                        break;
                    case "WA26PUE2":
                        ignoreInd = "Y";
                        break;
                    case "WA26PUE3":
                        ignoreInd = "Y";
                        break;
                    case "WA27PUE2":
                        ignoreInd = "Y";
                        break;
                    case "WA27PUE3":
                        ignoreInd = "Y";
                        break;
                    case "WBSM053":
                        ignoreInd = "Y";
                        break;
                    case "WBSM054A":
                        ignoreInd = "Y";
                        break;
                    case "WBSM054B":
                        ignoreInd = "Y";
                        break;
                    case "WM74WE1":
                        ignoreInd = "Y";
                        break;
                    case "IS0019E1":
                        ignoreInd = "Y";
                        break;
                    case "IS0019E2":
                        ignoreInd = "Y";
                        break;
                    case "IS0019E3":
                        ignoreInd = "Y";
                        break;
                    case "IS0018E1":
                        ignoreInd = "Y";
                        break;
                    case "IS0018E2":
                        ignoreInd = "Y";
                        break;
                    case "IS0018E3":
                        ignoreInd = "Y";
                        break;
                    case "IS0018E4":
                        ignoreInd = "Y";
                        break;
                    case "IS0018E5":
                        ignoreInd = "Y";
                        break;
                    case "IS0018E6":
                        ignoreInd = "Y";
                        break;
                    case "IS0018E7":
                        ignoreInd = "Y";
                        break;
                    case "IS0018E8":
                        ignoreInd = "Y";
                        break;
                    case "IS0018E9":
                        ignoreInd = "Y";
                        break;
                    case "IS0001E5":
                        ignoreInd = "Y";
                        break;
                    case "IS0001E6":
                        ignoreInd = "Y";
                        break;
                    case "IS0001E7":
                        ignoreInd = "Y";
                        break;
                    case "IS0001E8":
                        ignoreInd = "Y";
                        GXHtmlGenericTag messageImg = GXHtmlTagFactory.instance().newGenericTag("img");
                        messageImg.setAttribute("src", "images/system_ message_button.gif");
                        messageImg.setAttribute("id", "sysMessage");
                        messageImg.setPosition(1, 35);
                        messageImg.setAttribute("onclick", "gx_SubmitKey('[enter]')");
                        messageImg.setAttribute("onmouseover", "window.status='Enter';return true");
                        messageImg.setAttribute("onmouseout", "window.status='';return true");
                        e.getScreenTagModel().add(messageImg);
                        break;
                    case "IS8004E1":
                        ignoreInd = "Y";
                        break;
                    case "WE19PUE2":
                        ignoreInd = "Y";
                        break;
                    case "WG01PUE2":
                        ignoreInd = "Y";
                        break;
                    case "OS0062E1":
                        ignoreInd = "C";
                        break;
                    case "WD14PUE4":
                        ignoreInd = "C";
                        break;
                    case "WD16PUE4":
                        ignoreInd = "C";
                        break;
                    case "IS0001E9":
                        ignoreInd = "Y";
                        break;
                    default:
                        break;
                }
                if (ignoreInd == "N" || ignoreInd == "C")
                {
                    // Add help button to map for inactive help purpose

                    GXHtmlGenericTag helpGlobeImg = GXHtmlTagFactory.instance().newGenericTag("img");
                    helpGlobeImg.setAttribute("src", "images/help_globe.gif");
                    helpGlobeImg.setAttribute("id", "globeImg");
                    helpGlobeImg.setAttribute("title", "PF1");
                    helpGlobeImg.setPosition(1, 95);

                    //string pdfFile = "http://localhost/WCS/helppdf/"  + mapName + ".pdf";					
                    //helpGlobeImg.setAttribute("onclick","openPDF('" + pdfFile + "')");
                    helpGlobeImg.setAttribute("onclick", "gx_SubmitKeyInPos('G1_MAPNAME','[pf1]')");

                    helpGlobeImg.setAttribute("onmouseover", "window.status='PF1';return true");
                    helpGlobeImg.setAttribute("onmouseout", "window.status='';return true");

                    e.getScreenTagModel().add(helpGlobeImg);

                    // Add Command Line wording to screen

                    if (ignoreInd != "C")
                    {
                        GXILabelTag commandLineLbl = GXHtmlTagFactory.instance().newLabel("Command Line");
                        commandLineLbl.setAttribute("class", "commandlinetext");
                        e.getScreenTagModel().add(commandLineLbl);
                    }
                }

                // Add red button functionality to map 

                SqlCommand cmdRedButton = new SqlCommand("spReadRedButton", connBtnFunc);
                cmdRedButton.CommandType = CommandType.StoredProcedure;
                SqlParameter parmRedButton = cmdRedButton.Parameters.Add("@parmRedBtnFunc", SqlDbType.VarChar, 8);
                parmRedButton.Direction = ParameterDirection.Input;
                parmRedButton.Value = strBtnFunction;
                SqlDataReader drRedButton = cmdRedButton.ExecuteReader();

                imgColumn = 105;
                lblColumn = 100;
                string hasRedFunction = "N";

                if (drRedButton.HasRows == true)
                {
                    string strUserConn = ConfigurationSettings.AppSettings["conWCSFunc"];
                    SqlConnection connUserFunc = new SqlConnection(strUserConn);
                    connUserFunc.Open();

                    while (drRedButton.Read())
                    {
                        if (drRedButton.GetValue(4).ToString().Trim() == "K")
                        {
                            if (redTest == "Y")
                            {
                                if (drRedButton.GetValue(2).ToString().Trim() == "PF11")
                                {
                                    if (timeInd == "A")
                                    {
                                        hasRedFunction = "Y";
                                    }
                                }
                            }
                            else
                            {
                                hasRedFunction = "Y";
                            }
                        }
                        else
                        {
                            string strUserFunction = drRedButton.GetValue(2).ToString().Trim();
                            hasRedFunction = "N";
                            SqlCommand cmdUserFunction = new SqlCommand("spReadToolBarFunction", connUserFunc);
                            cmdUserFunction.CommandType = CommandType.StoredProcedure;
                            SqlParameter parmUserFunction = cmdUserFunction.Parameters.Add("@parmToolBarFunc", SqlDbType.VarChar, 14);
                            parmUserFunction.Direction = ParameterDirection.Input;
                            parmUserFunction.Value = logonId + strUserFunction;
                            SqlDataReader drUserFunction = cmdUserFunction.ExecuteReader();

                            if (drUserFunction.HasRows == true)
                            {
                                while (drUserFunction.Read())
                                {
                                    string funcType = drUserFunction.GetValue(6).ToString().Trim();
                                    if (funcType == "F")
                                    {
                                        hasRedFunction = "Y";
                                    }
                                }
                            }
                            drUserFunction.Close();
                        }
                        if (hasRedFunction == "Y")
                        {
                            GXHtmlGenericTag redImg = GXHtmlTagFactory.instance().newGenericTag("img");
                            GXILabelTag redLbl = GXHtmlTagFactory.instance().newLabel(drRedButton.GetValue(3).ToString().Trim());

                            imgColumn = imgColumn - 13;
                            redImg.setAttribute("src", "images/red_" + drRedButton.GetValue(3).ToString().ToLower().Trim() + ".jpg");
                            redImg.setPosition(25, imgColumn);
                            string redValue = drRedButton.GetValue(2).ToString().Substring(0, 1);

                            if (redValue == "1" | redValue == "2" | redValue == "3" | redValue == "4" | redValue == "5" | redValue == "6" | redValue == "7")
                            {
                                redLbl.setAttribute("onclick", "submitRadioKey('" + redValue + "')");
                                redImg.setAttribute("onclick", "submitRadioKey('" + redValue + "')");
                            }
                            else
                            {
                                redValue = drRedButton.GetValue(2).ToString().Substring(0, 2);
                                if (redValue == "DI" | redValue == "ER" | redValue == "DM")
                                {
                                    redLbl.setAttribute("onclick", "submitRadioKey('" + redValue + "')");
                                    redImg.setAttribute("onclick", "submitRadioKey('" + redValue + "')");
                                }
                                else
                                {
                                    if (redValue == "PF" | redValue == "pf")
                                    {
                                        redLbl.setAttribute("onclick", "gx_SubmitKey('" + drRedButton.GetValue(2).ToString().Trim() + "')");
                                        redImg.setAttribute("onclick", "gx_SubmitKey('" + drRedButton.GetValue(2).ToString().Trim() + "')");
                                    }
                                    else
                                    {
                                        redValue = drRedButton.GetValue(2).ToString().Substring(0, 3);
                                        if (redValue == "ESC" | redValue == "TOP" | redValue == "BOT" | redValue == "PRE")
                                        {
                                            redLbl.setAttribute("onclick", "placeIc('" + redValue + "')");
                                            redImg.setAttribute("onclick", "placeIc('" + redValue + "')");
                                        }
                                        else
                                        {
                                            if (drRedButton.GetValue(2).ToString().Trim() == "PRNT")
                                            {
                                                redLbl.setAttribute("onclick", "print_voucher()");
                                                redImg.setAttribute("onclick", "print_voucher()");
                                            }
                                            else
                                            {
                                                redLbl.setAttribute("onclick", "placeCommand('#" + drRedButton.GetValue(2).ToString().Trim() + "')");
                                                redImg.setAttribute("onclick", "placeCommand('#" + drRedButton.GetValue(2).ToString().Trim() + "')");
                                            }
                                        }
                                    }
                                }
                            }
                            redImg.setAttribute("class", "imgClass");
                            redImg.setAttribute("title", drRedButton.GetValue(2).ToString().ToString().Trim());
                            redImg.setAttribute("onmouseover", "window.status='" + drRedButton.GetValue(2).ToString().ToString().Trim() + "';return true;");
                            redImg.setAttribute("onmouseout", "window.status='';return true;");
                            e.getScreenTagModel().add(redImg);

                            lblColumn = lblColumn - 13;
                            redLbl.setPosition(27, lblColumn);
                            redLbl.setAttribute("class", "lblClass");
                            redLbl.setAttribute("onmouseover", "window.status='" + drRedButton.GetValue(2).ToString().Trim() + "';this.className='lblClass_over';return true;");
                            redLbl.setAttribute("onmouseout", "window.status='';this.className='lblClass';return true;");
                            redLbl.setAttribute("title", drRedButton.GetValue(2).ToString().Trim());

                            e.getScreenTagModel().add(redLbl);
                        }
                    }
                }
                drRedButton.Close();

                SqlCommand cmdGrayButton = new SqlCommand("spReadGrayButton", connBtnFunc);
                cmdGrayButton.CommandType = CommandType.StoredProcedure;
                SqlParameter parmGrayButton = cmdGrayButton.Parameters.Add("@parmGrayBtnFunc", SqlDbType.VarChar, 8);
                parmGrayButton.Direction = ParameterDirection.Input;
                parmGrayButton.Value = strBtnFunction;
                SqlDataReader drGrayButton = cmdGrayButton.ExecuteReader();

                if (drGrayButton.HasRows == true)
                {

                    GXITableTag tableGrayButton = GXHtmlTagFactory.instance().newTable();
                    GXITableRowTag trGrayButton = null;
                    GXITableCellTag tcGrayButton = null;
                    GXILinkTag hrefGrayButton = null;
                    GXHtmlGenericTag imgGrayButton = null;

                    GXITableTag tableGrayLabel = GXHtmlTagFactory.instance().newTable();
                    GXITableRowTag trGrayLabel = null;
                    GXITableCellTag tcGrayLabel = null;
                    GXHtmlGenericTag lblGrayLabel = null;
                    GXILinkTag hrefGrayLabel = null;

                    while (drGrayButton.Read())
                    {
                        string strUserConn = ConfigurationSettings.AppSettings["conWCSFunc"];
                        SqlConnection connUserFunc = new SqlConnection(strUserConn);
                        connUserFunc.Open();
                        SqlCommand cmdUserFunction = new SqlCommand("spReadToolBarFunction", connUserFunc);
                        cmdUserFunction.CommandType = CommandType.StoredProcedure;
                        SqlParameter parmUserFunction = cmdUserFunction.Parameters.Add("@parmToolBarFunc", SqlDbType.VarChar, 14);
                        parmUserFunction.Direction = ParameterDirection.Input;
                        parmUserFunction.Value = logonId + drGrayButton.GetValue(2).ToString().Trim();
                        SqlDataReader drUserFunction = cmdUserFunction.ExecuteReader();

                        if (drUserFunction.HasRows == true)
                        {

                            tcGrayButton = GXHtmlTagFactory.instance().newTableCell();
                            imgGrayButton = GXHtmlTagFactory.instance().newGenericTag("img");
                            hrefGrayButton = GXHtmlTagFactory.instance().newLink("");

                            tcGrayButton.setAttribute("class", "grayButtonTD");
                            tcGrayButton.setAttribute("align", "center");
                            tcGrayButton.setAttribute("title", drGrayButton.GetValue(2).ToString().ToString().Trim());
                            tcGrayButton.setAttribute("onmouseover", "window.status='" + drGrayButton.GetValue(2).ToString().Trim() + "';return true;");
                            tcGrayButton.setAttribute("onmouseout", "window.status='';return true;");
                            hrefGrayButton.setOnClick("placeCommand('#" + drGrayButton.GetValue(2).ToString().Trim() + "')");
                            imgGrayButton.setAttribute("src", "images/gray_" + drGrayButton.GetValue(3).ToString().Trim() + ".gif");

                            trGrayButton = GXHtmlTagFactory.instance().newTableRow();
                            trGrayButton.setAttribute("class", "grayButtonRow");
                            tableGrayButton.getRows().add(trGrayButton);

                            hrefGrayButton.getChildren().add(imgGrayButton);
                            tcGrayButton.getChildren().add(hrefGrayButton);
                            trGrayButton.getCells().add(tcGrayButton);

                            // Label

                            tcGrayLabel = GXHtmlTagFactory.instance().newTableCell();
                            lblGrayLabel = GXHtmlTagFactory.instance().newGenericTag("lbl");
                            hrefGrayLabel = GXHtmlTagFactory.instance().newLink("");

                            tcGrayLabel.setAttribute("class", "GrayLabelTD");
                            tcGrayLabel.setAttribute("align", "center");
                            tcGrayLabel.setAttribute("title", drGrayButton.GetValue(2).ToString().ToString().Trim());
                            tcGrayLabel.setAttribute("onmouseover", "window.status='" + drGrayButton.GetValue(2).ToString().Trim() + "';return true;");
                            tcGrayLabel.setAttribute("onmouseout", "window.status='';return true;");
                            hrefGrayLabel.setOnClick("placeCommand('#" + drGrayButton.GetValue(2).ToString().Trim() + "')");
                            lblGrayLabel.setInnerText(drGrayButton.GetValue(3).ToString().Trim());

                            trGrayLabel = GXHtmlTagFactory.instance().newTableRow();
                            trGrayLabel.setAttribute("class", "GrayLabelRow");
                            tableGrayLabel.getRows().add(trGrayLabel);

                            hrefGrayLabel.getChildren().add(lblGrayLabel);
                            tcGrayLabel.getChildren().add(hrefGrayLabel);
                            trGrayLabel.getCells().add(tcGrayLabel);
                        }
                        connUserFunc.Close();
                    }
                    tableGrayButton.setAttribute("class", "grayButtonTable");
                    tableGrayButton.setVisible(true, true);
                    e.getScreenTagModel().add(tableGrayButton);

                    tableGrayLabel.setAttribute("class", "grayLabelTable");
                    tableGrayLabel.setVisible(true, true);
                    e.getScreenTagModel().add(tableGrayLabel);
                }
                drGrayButton.Close();
            }
            SqlCommand cmdTableButton = new SqlCommand("spReadTableButton", connBtnFunc);
            cmdTableButton.CommandType = CommandType.StoredProcedure;
            SqlParameter parmTableButton = cmdTableButton.Parameters.Add("@parmTableBtnFunc", SqlDbType.VarChar, 8);
            parmTableButton.Direction = ParameterDirection.Input;
            parmTableButton.Value = strBtnFunction;
            SqlDataReader drTableButton = cmdTableButton.ExecuteReader();

            imgColumn = 9;
            lblColumn = 1;

            if (drTableButton.HasRows == true)
            {
                while (drTableButton.Read())
                {
                    GXHtmlGenericTag TableImg = GXHtmlTagFactory.instance().newGenericTag("img");
                    GXILabelTag TableLbl = GXHtmlTagFactory.instance().newLabel(drTableButton.GetValue(2).ToString().Trim());

                    TableImg.setAttribute("src", "images/table_help.jpg");
                    TableImg.setPosition(26, imgColumn);

                    TableLbl.setAttribute("onclick", "gx_SubmitKey('[pf1]')");
                    TableImg.setAttribute("onclick", "gx_SubmitKey('[pf1]')");
                    TableImg.setAttribute("class", "smallImg");
                    TableImg.setAttribute("title", "PF1");
                    TableImg.setAttribute("onmouseover", "window.status='PF1';return true;");
                    TableImg.setAttribute("onmouseout", "window.status='';return true;");
                    e.getScreenTagModel().add(TableImg);

                    TableLbl.setPosition(27, lblColumn);
                    TableLbl.setAttribute("class", "lblClass");
                    TableLbl.setAttribute("onmouseover", "window.status='" + drTableButton.GetValue(2).ToString().Trim() + "';this.className='lblClass_over';return true;");
                    TableLbl.setAttribute("onmouseout", "window.status='';this.className='lblClass';return true;");
                    TableLbl.setAttribute("title", drTableButton.GetValue(2).ToString().Trim());

                    e.getScreenTagModel().add(TableLbl);
                    imgColumn = imgColumn + 15;
                    lblColumn = lblColumn + 15;
                }
            }
            drTableButton.Close();
            connBtnFunc.Close();
        }
        searchInd = "***";
        if (label != null && label.getText().IndexOf(searchInd) >= 0)
        {
            txt = label.getText();
            txt = txt.Replace("*", "");
            label.setText(txt);
        }
        if (label != null && label.getId() != null)
        {
            if (label.getId() == "CONFIRM_PRINT")
            {
                if (label.getContent() == "N")
                {
                    txt = label.getText();
                    txt = txt.Replace("N", "Y");
                    label.setText(txt);

                }
            }
        }
        if (label != null && label.getId() != null)
        {
            if (label.getId().Trim() == "SKILLS")
            {
                if (label.getContent().Trim() == "Rating")
                {
                    label.setAttribute("class", "rating");
                }
                else
                {
                    label.setAttribute("class", "skills");
                    skillsInd = "Y";
                }
            }
        }
        if (skillsInd == "Y")
        {
            if (label != null && label.getId() != null)
            {
                if (label.getId().Trim().Length > 9)
                {
                    if (label.getId().Trim().Substring(0, 9) == "RATE_RED_" || label.getId().Trim().Substring(0, 9) == "RATE_GREE")
                    {
                        label.setVisible(false);
                    }
                }
            }
        }
        if (mapName == "WM58PEE1")
        {
            string textId = label.getId().Trim();
            if (label != null && label.getId() != null)
            {
                if (textId == "STREEK_NAAM_000" || textId == "NIE_GEVERIF_AANTAL_A_000"
                || textId == "NIE_GEVERIF_BEDRAG_A_000" || textId == "HOLD_AANTAL_000"
                || textId == "HOLD_BEDRAG_000" || textId == "GEVERIF_AANTAL_A_000"
                || textId == "GEVERIF_BEDRAG_A_000")
                {
                    label.setAttribute("class", "wm58pe");
                }
            }
        }
        if (mapName == "WY70PEE2")
        {
            if (label != null && label.getId() != null)
            {
                string textId = label.getId().Trim();
                if (textId == "TEXT_CHANGED_000" || textId == "TEXT_CHANGED_002")
                {
                    if (label.getText().Trim() == "CHANGED FROM:" || label.getText().Trim() == "CHANGED TO:")
                    {
                        label.setAttribute("class", "wy70pee2");
                    }
                }
            }
        }

    }
    public override void onNewTextField(GXRenderEvent e, GXITextFieldTag textField)
    {
        if (textField != null && textField.getId() != null)
        {
            if (textField.getId().Trim() == "CONFIRM_PRINT")
            {
                if (textField.getContent() == "N")
                {
                    textField.setText("Y");
                }
            }
        }
        if (textField != null && textField.getId() != null)
        {
            if (textField.getId().Trim() == "TIME_CHARGE_IND" && redTest == "Y")
            {
                functionInd = "Y";
                if (textField.getContent().Trim() == "X")
                {
                    timeInd = "A";
                }
            }
        }

        int x = textField.getId().Trim().Length;
        string y = textField.getId();
        if (textField != null && textField.getId() != null)
        {
            if (textField.getId().Trim().Length > 6)
            {
                if (textField.getId().Substring(0, 6) == "RATING")
                {
                    int radioRow = 0;
                    int radioColumn = 0;
                    int radioIndex = Convert.ToInt32(textField.getId().Substring(7, 3));
                    GXIField inputTag = e.getHostScreen().getFieldInstance("RATING", radioIndex);
                    if (!inputTag.isProtected())
                    {
                        radioRow = textField.getPosition().getRow();
                        radioColumn = textField.getPosition().getColumn();
                        GXHtmlGenericTag radioImg = GXHtmlTagFactory.instance().newGenericTag("input");
                        radioImg.setAttribute("type", "checkbox");
                        radioImg.setAttribute("id", "cmdCheckBox");
                        radioImg.setAttribute("value", textField.getId().Trim());
                        radioImg.setAttribute("name", "cmdCheckBox");
                        radioImg.setAttribute("style", "position: absolute!important");
                        radioImg.setPosition(radioRow, radioColumn);
                        if (inputTag.getContent().Trim() == "X")
                        {
                            radioImg.setAttribute("Checked", "True");
                        }
                        e.getScreenTagModel().add(radioImg);
                    }
                }
            }
        }

        if (textField != null && textField.getId() != null)
        {
            if (textField.getId().Substring(0, 3) == "CMD")
            {
                int radioRow = 0;
                int radioColumn = 0;
                int radioIndex = Convert.ToInt32(textField.getId().Substring(4, 3));
                GXIField inputTag = e.getHostScreen().getFieldInstance("CMD", radioIndex);
                if (!inputTag.isProtected())
                {
                    radioRow = textField.getPosition().getRow();
                    radioColumn = textField.getPosition().getColumn();
                    radioColumn = radioColumn - 1;
                    GXHtmlGenericTag radioImg = GXHtmlTagFactory.instance().newGenericTag("input");
                    if (radioBtn == "Y")
                    {
                        radioImg.setAttribute("type", "radio");
                    }
                    else
                    {
                        radioImg.setAttribute("type", "checkbox");
                    }
                    radioImg.setAttribute("id", "cmdRadioBtn");
                    radioImg.setAttribute("value", textField.getId().Trim());
                    radioImg.setAttribute("name", "cmdRadioBtn");
                    radioImg.setAttribute("z-index", "9");
                    radioImg.setAttribute("position", "absolute!important");
                    if (mapName == "WA22PEE1" || mapName == "WG34PEE1")
                    {
                    }
                    else
                    {
                        radioImg.setAttribute("onclick", "submitRadioKey('" + "X" + "')");
                    }
                    radioImg.setPosition(radioRow, radioColumn);
                    e.getScreenTagModel().add(radioImg);
                }
            }
        }
    }

    public override void onNewTable(GXRenderEvent e, GXITableTag table)
    {
        // Add here code that handles tables (As defined in ApplinX composer).
        // Use e parameter to access the screen tag model and the host screen.
    }
    public override void onNewTableCell(GXRenderEvent e, GXITableCellTag tableCell)
    {
        // Add here code that handles table rows (as children of onNewTableRow).
        // Use e parameter to access the screen tag model and the host screen.
        //string displayId = tableCell.getChildren().get(0).getId();

        if (tableCell != null && tableCell.getId() != null)
        {
            string radioId = tableCell.getChildren().get(0).getId().Trim();
            int idLenght = radioId.Length;
            if (idLenght > 13)
            {
                if (radioId.Substring(0, 13) == "SELECT_RADIO_")
                {
                    int radioIndex = Convert.ToInt32(radioId.Substring(13, 3));
                    GXIField inputTag = e.getHostScreen().getFieldInstance("SELECT_RADIO", radioIndex);
                    if (!inputTag.isProtected())
                    {
                        GXHtmlGenericTag radioImg = GXHtmlTagFactory.instance().newGenericTag("input");
                        radioImg.setAttribute("class", "gx_rdo1");
                        radioImg.setAttribute("type", "radio");
                        radioImg.setAttribute("id", "cmdRadioBtn");
                        radioImg.setAttribute("onclick", "submitRadioKey('" + "X" + "')");
                        radioImg.setAttribute("value", radioId);
                        radioImg.setAttribute("name", "cmdRadioBtn");
                        tableCell.getChildren().add(radioImg);
                    }
                }
            }
            if (radioId.Substring(0, 3) == "CMD")
            {
                int radioIndex = Convert.ToInt32(radioId.Substring(4, 3));
                GXIField inputTag = e.getHostScreen().getFieldInstance("CMD", radioIndex);
                if (!inputTag.isProtected())
                {
                    GXHtmlGenericTag radioImg = GXHtmlTagFactory.instance().newGenericTag("input");
                    radioImg.setAttribute("class", "gx_rdo1");
                    radioImg.setAttribute("type", "checkbox");
                    radioImg.setAttribute("id", "cmdCheckBox");
                    radioImg.setAttribute("value", radioId);
                    radioImg.setAttribute("name", "cmdCheckBox");
                    radioImg.setAttribute("z-index", "9");
                    tableCell.getChildren().add(radioImg);
                    if (inputTag.getContent().Trim() == "X")
                    {
                        radioImg.setAttribute("Checked", "True");
                    }
                }
            }
            if (radioId.Substring(0, 3) == "PF_")
            {
                helpId = tableCell.getChildren().get(0).getId().Trim();
                GXHtmlGenericTag helpImg = GXHtmlTagFactory.instance().newGenericTag("input");
                helpImg.setAttribute("src", "images/help_green.gif");
                helpImg.setAttribute("class", "helpImg");
                helpImg.setAttribute("type", "image");
                helpImg.setAttribute("id", helpId);
                helpImg.setAttribute("title", "PF10");
                helpId = helpId.Replace("PF_", "");
                helpImg.setAttribute("onclick", "gx_SubmitKeyInPos('" + helpId + "','[pf10]')");
                helpImg.setAttribute("onmouseover", "window.status='PF10';return true");
                helpImg.setAttribute("onmouseout", "window.status='';return true");
                tableCell.getChildren().add(helpImg);
            }
            if (radioId.Substring(0, 3) == "PFM")
            {
                helpId = tableCell.getChildren().get(0).getId().Trim();
                GXHtmlGenericTag helpImg = GXHtmlTagFactory.instance().newGenericTag("input");
                helpImg.setAttribute("src", "images/help_green.gif");
                helpImg.setAttribute("class", "helpImg");
                helpImg.setAttribute("type", "image");
                helpImg.setAttribute("id", helpId);
                helpImg.setAttribute("title", "PF10");
                helpId = helpId.Replace("PF_", "");
                helpImg.setAttribute("onclick", "gx_SubmitKeyInPos('" + helpId + "','[enter]')");
                helpImg.setAttribute("onmouseover", "window.status='enter';return true");
                helpImg.setAttribute("onmouseout", "window.status='';return true");
                tableCell.getChildren().add(helpImg);
            }
            string xx = tableCell.getAttribute("dir");
            if (tableCell.getAttribute("dir") == "RTL")
            {
                //			tableCell.removeAttribute("dir");
                tableCell.setAttribute("style", "align=right");
                alignRight = "Y";
            }
            string spanId = tableCell.getChildren().get(0).getTagName();
            if (alignRight == "Y")
            {
                if (spanId == "span")
                {
                    tableCell.setAttribute("class", "align=right");
                }
            }
            alignRight = "N";
            if (mapName == "WG41PEE1")
            {
                if (tableCell.getChildren().get(0).getContent().Trim() == "")
                {
                    redInd = redInd + 1;
                }
                if (idLenght > 19)
                {
                    if (radioId.Substring(0, 19) == "SUBMIT_DESCRIPTION_")
                    {
                        if (redInd == 6)
                        {
                            if (tableCell.getChildren().get(0).getContent().Trim() != "")
                            {
                                tableCell.setAttribute("class", "wg41pe");
                            }
                        }
                        redInd = 0;
                    }
                }
            }
            if (mapName == "WM13PUE3")
            {
                if (radioId == "DIENS_NO_000" || radioId == "KONTR_NO_000" || radioId == "BEGUNS_KDE_000"
                    || radioId == "ADVIES_NO_000" || radioId == "BET_NO_9X_000" || radioId == "BET_IND_000"
                    || radioId == "BED_BETBAAR_000" || radioId == "REG_DAT_000" || radioId == "L1_ID_000")
                {
                    tableCell.setAttribute("class", "wg41pe");
                }
            }
            if (mapName == "WH33PUE1" || mapName == "WH34PEE1")
            {
                if (idLenght > 7)
                {
                    if (radioId.Substring(0, 7) == "LOCAL_D")
                    {
                        if (tableCell.getChildren().get(0).getContent().Trim() != "")
                        {
                            string x = "*";

                            if (tableCell.getChildren().get(0).getContent().Trim().Substring(0, 1) != "-")
                            {
                                if (tableCell.getChildren().get(0).getContent().Trim().IndexOf(x) >= 0)
                                {
                                    tableCell.setAttribute("class", "local_d4");
                                    string txt1 = tableCell.getChildren().get(0).getContent().Trim();
                                    string txt2 = txt1.Replace("*", " ");
                                    tableCell.getChildren().initialize();
                                    tableCell.setText(txt2);
                                }
                                else
                                {
                                    tableCell.setAttribute("class", "local_d3");
                                }
                            }
                        }
                    }
                }
            }
            if (mapName == "WH22PEE1" || mapName == "WH33PUE2" || mapName == "WH34PEE2" || mapName == "WH28PEE1"
                || mapName == "WH06PEE1")
            {
                if (idLenght > 7)
                {
                    if (radioId.Substring(0, 7) == "LOCAL_D")
                    {
                        if (tableCell.getChildren().get(0).getContent().Trim() != "")
                        {
                            string x = "REGION";

                            if (tableCell.getChildren().get(0).getContent().Trim().Substring(0, 1) != "-")
                            {
                                if (tableCell.getChildren().get(0).getContent().Trim().IndexOf(x) >= 0)
                                {
                                    tableCell.setAttribute("class", "local_d1");
                                }
                                else
                                {
                                    tableCell.setAttribute("class", "local_d2");
                                }
                            }
                        }
                    }
                }
            }
            if (mapName == "WH36PEE1")
            {
                if (idLenght > 7)
                {
                    if (radioId.Substring(0, 7) == "LOCAL_D")
                    {
                        if (tableCell.getChildren().get(0).getContent().Trim() != "")
                        {
                            string x = "PRINCIPAL";
                            string y = "PROFESSIONAL";
                            if (tableCell.getChildren().get(0).getContent().Trim().IndexOf(x) >= 0)
                            {
                                tableCell.setAttribute("class", "local_wh36_1");
                            }
                            if (tableCell.getChildren().get(0).getContent().Trim().IndexOf(y) >= 0)
                            {
                                tableCell.setAttribute("class", "local_wh36_2");
                            }
                        }
                    }
                }
            }
        }
    }
}

