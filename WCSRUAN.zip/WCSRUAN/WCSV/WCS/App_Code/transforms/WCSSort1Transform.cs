using System;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;
using com.sabratec.applinx.baseobject;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using com.sabratec.util;
using com.sabratec.applinx.presentation.tags.html;
using System.Web.UI;


	/// <summary>
	/// This class is receiving an event on the creation of each type of tag
	/// such as: "onNewTextField", "onNewLabel", "onNewButton", etc. It should be used for tag
	/// level manipulations, such as changing the content and attributes, adding icons, etc.
	/// </summary>
public class WCSSort1Transform : GXTagListener
{
	private string searchInd;
	private string txt;
	private int helpRow;
	private int helpColumn;
	private string helpId;
	
	public override void onNewLabel(GXRenderEvent e, GXILabelTag label)
	{
		// Add here code that handles label fields (Host protected fields).
		// Use e parameter to access the screen tag model and the host screen.
		searchInd = "WCS";
		if (label != null && label.getText().IndexOf(searchInd) >= 0)
		{
			txt = label.getText();
			txt =  txt.Replace("WCS","WIMS");
			label.setText(txt);
		}
		searchInd = ".:";
		if (label != null && label.getText().IndexOf(searchInd) >= 0)
		{
			txt = label.getText();
			txt =  txt.Replace("..","");
			txt =  txt.Replace(" .","");
			txt =  txt.Replace(".:",":");
			label.setText(txt);
		}

		if (label.getId().Substring(0,3)== "PF1")
		{
			if (label.getContent() == "*")
			{
				helpId = label.getId();
				helpRow = label.getPosition().getRow();
				helpColumn = label.getPosition().getColumn();
				helpColumn = helpColumn - 1;
			
				label.setPosition(new com.sabratec.util.GXPosition(helpRow,helpColumn));
				txt = label.getText();
				txt = txt.Replace("*","");
				label.setText(txt);
								
				GXHtmlGenericTag helpImg = GXHtmlTagFactory.instance().newGenericTag("input");
				helpImg.setAttribute("src","images/help_book.gif");
				helpImg.setAttribute("class","helpImg");
				helpImg.setAttribute("type","image");
				helpImg.setAttribute("id",helpId);
				helpImg.setAttribute("title","PF1");
				helpId = helpId.Replace("PF1_","");
				helpImg.setAttribute("onclick","gx_SubmitKeyInPos('" + helpId + "','[pf1]')");
				helpImg.setAttribute("onmouseover","window.status='PF1';return true");
				helpImg.setAttribute("onmouseout","window.status='';return true");

				e.getScreenTagModel().replace(label,helpImg);
			}
		}		
	}

}

