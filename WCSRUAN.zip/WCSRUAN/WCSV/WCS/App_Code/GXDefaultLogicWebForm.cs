using System;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.sabratec.dotnet.framework;
using com.sabratec.applinx.baseobject;
using com.sabratec.dotnet.framework.web;
using com.sabratec.applinx.framework;


	/// <summary>
	/// Summary description for GXAbstractWebPage.
	/// </summary>
	public class GXDefaultLogicWebForm : GXBasicWebForm
	{
		protected override void OnLoad(EventArgs e){
			gx_doFrameWorkLogic();
			base.OnLoad(e);
		}
					
		protected override void OnInit(EventArgs e){
			base.OnInit(e);
		}
	}
