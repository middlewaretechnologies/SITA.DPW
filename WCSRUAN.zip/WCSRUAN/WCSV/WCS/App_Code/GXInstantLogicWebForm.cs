using System;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.sabratec.dotnet.framework;
using com.sabratec.applinx.baseobject;
using com.sabratec.applinx.framework.web;

using com.sabratec.applinx.presentation;
using com.sabratec.applinx.presentation.transforms;
using com.sabratec.util;

public class GXInstantLogicWebForm : GXDefaultLogicWebForm
{
	protected override void OnInit(EventArgs e){
		base.OnInit(e);

		gx_appConfig.IsInstant = true;

	}

	protected override void OnPreRender(EventArgs e)
	{
		base.OnPreRender(e);

		// Instant configuration

		registerInstantTransforms();
	}

	public virtual void registerInstantTransforms() 
	{

		//gx_appConfig.InstantConfig.addTagListener(new UserTagTransform1());
		//gx_appConfig.InstantConfig.addCompletionListener(new UserCompletionTransform1());
		// add here more transform registrations
	}


				
}
