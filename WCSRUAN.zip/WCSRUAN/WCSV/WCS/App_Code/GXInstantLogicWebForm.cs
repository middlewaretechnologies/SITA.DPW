using System;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.sabratec.dotnet.framework;
using com.sabratec.applinx.baseobject;
using com.sabratec.applinx.framework.web;

using com.sabratec.applinx.presentation.transforms;
using com.sabratec.util;
using com.sabratec.applinx.presentation;

public class GXInstantLogicWebForm : GXDefaultLogicWebForm
{
    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);

        // Instant configuration

        gx_appConfig.IsInstant = true;
        gx_appConfig.CaptureBrowserClose = true;

        // Instant configuration

        // Sets the font size by the end user resolution 
        //gx_appConfig.InstantConfig.FontSize = GXWebUtil.getBestFitFontSize(this);
        //gx_appConfig.InstantConfig.FontSize = 12;

        gx_appConfig.InstantConfig.EmulationConfig.setRenderEmulationAttributes(true);
       // gx_appConfig.InstantConfig.EmulationConfig.setColorMode(GXRenderConfig.COLORS_ALL);
        gx_appConfig.InstantConfig.setRenderArea(new GXRectangle(4, 1, 24, 80));
       // gx_appConfig.InstantConfig.HostKeysConfig.setRenderingType(GXRenderConfig.HOSTKEYS_LINKS);
       // gx_appConfig.InstantConfig.GuiElementsConfig.setAlignment(GXGuiElementsTransformConfig.ALIGNMENT_HORIZONTAL);
        gx_appConfig.InstantConfig.WindowFrameConfig.setEnabled(true);
        gx_appConfig.InstantConfig.TableConfig.setRenderAlternatingCssClass(true);
        gx_appConfig.InstantConfig.TableConfig.setTableAlternating1CssClass("gx_tbl_alternating1");
        gx_appConfig.InstantConfig.TableConfig.setTableAlternating2CssClass("gx_tbl_alternating2");
        // End of Instant configuration

    }

    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);
        registerInstantTransforms();
    }

    public virtual void registerInstantTransforms()
    {
        gx_appConfig.InstantConfig.addTagListener(new WCSUserTransform());
    }
}
