using System;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.sabratec.dotnet.framework;
using com.sabratec.applinx.baseobject;
using com.sabratec.dotnet.framework.web;
using com.sabratec.applinx.framework;


	/// <summary>
	/// Summary description for GXAbstractWebPage.
	/// </summary>
	public class GXDefaultLogicWebForm2 : GXBasicWebForm
	{
		protected override void OnLoad(EventArgs e){
			gx_doFrameWorkLogic();
			base.OnLoad(e);
			
		}

		protected override void OnInit(EventArgs e){
			//gx_appConfig.UseKeyboardPFKeys  = true;

			//gx_appConfig.SupportDupAndFieldMark = true;

			gx_appConfig.CaptureTagsEvents = true;

			//gx_appConfig.UseModalWindows = true;
			// ^^^ NOTE : When turning gx_appConfig.UseModalWindows = true, please make sure : 
			//GX_WarnOnBrowserClose = false; GX_LogoffOnBrowserClose = false ; <- in _inc_applconf.js , _inc_instantconf.js

			gx_appConfig.ScreenLocker = "template\\screenLocker.ascx";
	
			base.OnInit(e);
		}
	}
