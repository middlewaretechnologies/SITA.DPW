using System;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.HtmlControls;

using com.sabratec.util;
using com.sabratec.applinx.framework;
using com.sabratec.applinx.baseobject;
using com.sabratec.dotnet.framework.events;
using com.sabratec.applinx.baseobject.table;
using com.sabratec.dotnet.framework.web.tables;
using com.sabratec.dotnet.ci;
using com.sabratec.applinx.framework.emulation.ftp.dialog;
using com.sabratec.util.logger;

using com.sabratec.applinx.framework.web;

	/// <summary>
	/// Summary description for GXAbstractWebPage.
	/// </summary>
	public class GXBasicWebForm : com.sabratec.dotnet.framework.web.GXAbstractWebForm
	{

		public override void gx_initSessionConfig(){
		
			/****************************************************************************************************************************
				ApplinX Server URL and Application name settings are in web.config - <appSettings>
			*****************************************************************************************************************************/
			gx_appConfig.SessionConfig.ServerURL = ConfigurationSettings.AppSettings["GXServerURL"];
			gx_appConfig.SessionConfig.ApplicationName = ConfigurationSettings.AppSettings["GXApplicationName"];

			gx_appConfig.SessionConfig.SessionId= "SID"+ Session.SessionID;
			gx_appConfig.SessionConfig.Password = "";
			gx_appConfig.SessionConfig.Description = Request["REMOTE_ADDR"];
			gx_appConfig.NaturalDataTransferConfig.AutomaticDownload = true;
			//gx_appConfig.SessionConfig.ServiceName = "<YOUR SERVICE NAME>";

			// Optional variables for all the project pages, list of variables can be found in the documentation
			//for hebrew logical
			//gx_appConfig.SessionConfig.addVariable(GXBaseObjectConstants.GX_VAR_ENCODING_LOGICAL, "true");

			//for device name 
			//gx_appConfig.SessionConfig.addVariable(GXBaseObjectConstants.GX_VAR_DEVICE_NAME, "<YOUR_DEVICE_NAME>");
		}

		protected override void OnInit(EventArgs e)
		{

			base.OnInit(e);
	
		// General configurations
			gx_appConfig.DesignMode = true;
			gx_appConfig.TrimLabels = false;
			gx_appConfig.FieldTypesInUse = GXFrameworkHandler.GX_USE_APPFIELDS;
			gx_appConfig.ReflectHostProtected  = true;
			gx_appConfig.MapPath ="";

			//gx_appConfig.UseFolders = true;
			//gx_appConfig.VirtualDir = "WCS"; // Required when gx_appConfig.UseFolders = true;

			//gx_appConfig.UseScreenGroups = false; // used for automatically load a page for a screen group

			// used for binding the current host screen to a template part. You may add aditional lines for more template parts
			//gx_appConfig.addBindingToTemplatePart("pageheader"); 

			//gx_appConfig.PerformSyncCheckInInstant = false;

			gx_appConfig.UseCache = false;
		// End General configurations

		// Tables in generated pages configuration
			//gx_appConfig.TableBuildConfig.AlternateColors = true;
			//gx_appConfig.TableBuildConfig.AlternateCssName = "gx_tbl_alternating2";
			//gx_appConfig.TableBuildConfig.DynamicFieldCheck = true;
			//gx_appConfig.TableBuildConfig.FromRow = 0;
			//gx_appConfig.TableBuildConfig.ToRow = 0;

		// End tables in generated pages configuration

/*		
			// For Performance test purposes only !!! - Uncomment the following line to activate framework performance log 
			// under the project, logs folder.
			// You also need to uncomment the following lines of gx_logger settings
	        gx_appConfig.WritePerformanceLog = true;

	        // Logger settings - uncomment the following lines to activate framework log
	        gx_logger.setDefaultDestination(Server.MapPath(".") + "\\logs\\log.csv", true);
	        gx_logger.setLogLevel(0x0008); // possile values: Debug - 0x0008 , Message - 0x0004 , Warning - 0x0002 , Error - 0x0001
	        gx_logger.setLogToStdout(true);
	        gx_logger.setSynchronic(true);
	        gx_logger.setEnableAllIndices(true);
*/		

		// Macro configuration
			//gx_appConfig.MacroConfig.setUserName(Request["REMOTE_ADDR"]);
			//gx_appConfig.MacroConfig.setMacrosFolder(Server.MapPath("z_emulationDialogs\\userMacros"));
			//gx_appConfig.MacroConfig.setEncryptData(false);
		// End of macro configuration

		// FTP configuration
	        //gx_appConfig.FtpConfig.setHostType(GXFtpConfig.GX_FTP_BYAPPLINX);
			//gx_appConfig.FtpConfig.setHostType(GXFtpConfig.GX_FTP_AS400);
		// End FTP configuration
			
			// Events capturing
			this.gx_preConnect += new GXPreConnectEventHandler(user_preConnect);
			this.gx_postConnect += new GXPostConnectEventHandler(user_postConnect);
			this.gx_preSendKeys += new GXPreSendKeyEventHandler(user_preSendKeys);
			this.gx_postSendKeys += new GXPostSendKeyEventHandler(user_postSendKeys);
			this.gx_screenSeqMismatch += new GXScreenSeqMismatchEventHandler(user_screenSeqMismatch);
			this.gx_changeNextForm += new GXChangeNextFormEventHandler(user_changeNextForm);
			this.gx_preSyncHostWithForm +=new GXPreSyncHostWithFormEventHandler(user_preSyncHostWithForm);
			this.gx_preFillForm +=new EventHandler(user_preFillForm);
			this.gx_postFillForm +=new EventHandler(user_postFillForm);
			this.gx_preOpenWin +=new GXPreOpenWinEventHandler(user_preOpenWin);
			// End of events capturing
		}

		// Called by the framework when a performance result of one page is ready
		public override void gx_writePerformanceData(GXIPerformanceData performanceData)
		{
			// false - to write detailed result in a few lines per screen, true - to write the result to one line per screen (for statistics)
			// can be overridden to write the result to DB
			GXPerformanceUtil.writePeformanceLogToLogger(performanceData,true);
		}

		public override void gx_fillTable()
		{

			base.gx_fillTable();

			// ^^ delete the base call when uncommenting
			// template code for customizing the table 
			// copy this function to any page you desire to customize the table.
//			GXITable gx_table = gx_session.getTable();
			/*
						// or
			//GXITable gx_table = gx_session.getTable("<YOUR_PATH_BASED_TABLE>");

			GXTablesHandler.fillHtmlTableFromGXTable("<YOUR_HTML_TABLE_CONTROL>",gx_table,this,gx_appConfig.TableBuildConfig);
*/			
		}

		protected void user_preConnect(object sender,GXPreConnectEventArgs e){
		// Occurs before gx_connect , gx_attach 
		// Use e.isNewSession  to know if the user is going to be attached to an existing session or connecting to a new one. 
		// Use e.sessionConfig to change the connect to ApplinX server parameters
		}

		protected void user_postConnect(object sender,GXPostConnectEventArgs e){
		// occurs after gx_connect , gx_attach 
		// use e.isNewSession to know if the user was attached to an existing session or connected to a new one.
		}

		protected void user_screenSeqMismatch(object sender,GXScreenSeqMismatchEventArgs e)
		{
			// Occurs if the form seq. screen number is different from the gx_session seq. screen number.
			// Use e.sendToHost  to send the data to the host any way.
		}

		protected void user_preSendKeys(object sender,GXPreSendKeyEventArgs e)
		{
		// Occurs before gx_processHostKeyRequest(GXSendKeysRequest sendKeyRequest),
		// which is activated from a browser pf key or when ENTER is pressed, or javascript:gx_SubmitKey(key).
		// Use e.sendKeyRequest to change the send key request to ApplinX server.
			string x = e.sendKeyRequest.getKeys();
			string y = x;
		}

		protected void user_postSendKeys(object sender,GXPostSendKeyEventArgs e){
		// Occurs after gx_processHostKeyRequest(GXSendKeysRequest sendKeyRequest),
		// which is activated from a browser pf key or when ENTER is pressed, or javascript:gx_SubmitKey(key)

		}

		protected void user_changeNextForm(object sender,GXChangeNextFormEventArgs e){
		// occurs before loading next page , by gx_handleHostResponse
		// use e.nextForm , for example logon.aspx , to change the next page
			
		}

		protected void user_preFillForm(object sender,EventArgs e){
		// Occurs before gx_fillForm() or gx_fillForm(GXScreensCollection screen)
		
		}

		protected void user_postFillForm(object sender,EventArgs e){
		// Occurs after gx_fillForm() or gx_fillForm(GXScreensCollection screen)
		}
		protected void user_preSyncHostWithForm(object sender,GXPreSyncHostWithFormEventArgs e){
		// Occurs in before gx_syncHostWithForm , used to add parameters to the map path
		}

		public override void gx_processHostKeyRequest(GXSendKeysRequest sendKeyRequest){
			// This function is activated from a browser pf key or enter was pressed , or javascript:gx_SubmitKey(key)
			base.gx_processHostKeyRequest(sendKeyRequest);
		}

		// User exits for pop-ups manager
		public override void gx_refreshWindow(Object sender ,EventArgs e)
		{
		// Occurs when a modal window is closed , the event is on the main window page
			base.gx_refreshWindow(sender,e);
		}
		public override void gx_closeWindow(Object sender ,EventArgs e){
		// Occurs when a modal window is closed, in the modal window page
			gx_doCloseWindow("[pf3]");
		}

		public override void gx_closeMainWindow(Object sender ,EventArgs e)
		{
			// Occurs when the browser is closed, calls the logoff page by default.
			base.gx_closeMainWindow(sender ,e);
		}

		protected void user_preOpenWin(object sender,GXPreOpenWinEventArgs e)
		{
		// Occurs before a window is opened, use e.openWin = false, to cancel opening the window,
		// and to change the window size.

//			if (gx_session.getScreen().getName() ==  ...){
//				e.openWin = false;
//			}
		}
		// End of user exits for pop-ups manager 

		// User exits for tables
		public override void gx_changeTr(int RowIndex,HtmlTableRow tr,GXITableRow row)
		{
			// Occurs every time a new table row (TR) with run-time data is created.
			// Allows you to customize the TR according to the current host row.

			// if a certain field contains dashes hide the row    
			//				if (row.getItemContent("G1_APPLIK").IndexOf("OPW") >= -1){
			//					tr.Visible = false;
			//				}
		}
		public override void gx_changeTd(int ColIndex,HtmlTableCell td,GXITableRow row){
			//Occurs every time a new table cell TD with run-time data is created.
			//Allows you to customize the table data TD according to the current host
			//row.
			

			// if a certain field is hidden, change the css class name to a disabled CSS class
			//				if ( ((GXFieldTableCell)row.getItem("<COLUMN_NAME>")).isVisible() == true){
			//					td.Attributes["class"] = "<DISABLE_GRAY_CSS_CLASS_NAME>";
			//				}
		}
		public override void gx_changeControl(int ColIndex,HtmlTableCell td,Control ctrl,GXITableRow row){
			// Occurs every time a new control inside a TD with run-time data is created.
			// Allows you to customize the controls according to the current host row.

			// if the created element is a link, get it's content from a desired column
			//				if (ctrl is HtmlAnchor){
			//					HtmlAnchor myAnchor= (HtmlAnchor)ctrl;
			//					myAnchor.InnerHtml = row.getItemContent("<COLUMN_NAME>");
			//				}
		}
		// End of user exits for tables
	}
