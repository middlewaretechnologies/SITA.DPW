//Validity checks variables
//----------------------------------------------------
//Uncomment to customize the values of these variables
//----------------------------------------------------
//gx_doValidityChecks = false;
//gx_showErrMsgAsPopupDialog = true;
//gx_bgColorOfErrField = "00ff00";
//GX_FIELD_DATA_TYPE_ALPHANUMERIC_MSG="User message example - ���p̨���ނ֑S�p�ް������͂��ꂽ -  \"$VALUE$\""
//GX_FIELD_DATA_TYPE_ALPHANUMERIC_MSG = "The application can not accept \"$VALUE$\" (contains DBCS) in AlphaNumeric field.";
//GX_FIELD_DATA_TYPE_NUMERIC_MSG = "The application can not accept \"$VALUE$\" (contains non numeric characters) in Numeric field.";
//GX_FIELD_DATA_TYPE_DBCS_CAN_CREATE_SISO_MSG = "The value \"$VALUE$\" is too long for the field.";
//----------------------------------------------------

    // event handlers
    // ==============
    function user_TextOnFocus(currTextbox) {
    	//return non-zero to disable system event handler
    	//your code here:

		// call page function if exists
    	if (window.page_TextOnFocus){
    		page_TextOnFocus();
    	}
    	return 0;
    }
    
    function user_TextOnBlur(currTextbox) {
    	//return non-zero to disable system event handler
    	//your code here:
    	
		// call page function if exists
    	if (window.page_TextOnBlur){
    		page_TextOnBlur();
    	}
    	return 0;
    }
    
    function user_TextOnChange(currTextbox) {
    	//return non-zero to disable system event handler
    	//your code here:

		// call page function if exists
    	if (window.page_TextOnChange){
    		page_TextOnChange();
    	}
    	
    	return 0;
    }
    
    function user_TextOnClick(currTextbox) {
    	//return non-zero to disable system event handler
    	//your code here:

		// call page function if exists
    	if (window.page_TextOnClick){
    		page_TextOnClick();
    	}

    	return 0;
    }
    
    function user_TextOnKeyDown(currTextbox) {
    	//return non-zero to disable system event handler
    	//your code here:

		// call page function if exists
    	if (window.page_TextOnKeyDown){
    		page_TextOnKeyDown(currTextbox);
    	}

    	return 0;
    }
    
    function user_TextOnKeyPress(currTextbox) {
    	//return non-zero to disable system event handler
    	//your code here:

		// call page function if exists
    	if (window.page_TextOnKeyPress){
    		page_TextOnKeyPress();
    	}

    	return 0;
    }
    
    function user_TextOnKeyUp(currTextbox) {
    	//return non-zero to disable system event handler
    	//your code here:
    	
		// call page function if exists
    	if (window.page_TextOnKeyUp){
    		page_TextOnKeyUp();
    	}
    	
    	return 0;
    }
    
    function user_LabelOnClick(currLabel) {
    	//return non-zero to disable system event handler
    	//your code here:

		// call page function if exists
    	if (window.page_LabelOnClick){
    		page_LabelOnClick();
    	}

    	return 0;
    }
	
    function user_LabelOnDblClick(currLabel) {
    	//return non-zero to disable system event handler
    	//your code here:
    	
    	// call page function if exists
    	if (window.page_LabelOnDblClick){
    		page_LabelOnDblClick();
    	}

    	return 0;
    }
    
    function user_WindowOnLoad(currWindow) {
    	//return non-zero to disable system event handler
    	//your code here:

		// call page function if exists
    	if (window.page_WindowOnLoad){
    		page_WindowOnLoad();
    	}
    	
    	return 0;
    }
    
    function user_WindowOnUnLoad(currWindow) {
    	//return non-zero to disable system event handler
    	//your code here:

		// call page function if exists
    	if (window.page_WindowOnUnLoad){
    		page_WindowOnUnLoad();
    	}
    	
    	return 0;
    }
    
    function user_WindowOnFocus(currWindow) {
    	//return non-zero to disable system event handler
    	//your code here:

		// call page function if exists
    	if (window.page_WindowOnFocus){
    		page_WindowOnFocus();
    	}
    	
    	return 0;
    }
    
    function user_WindowOnBlur(currWindow) {
    	//return non-zero to disable system event handler
    	//your code here:

		// call page function if exists
    	if (window.page_WindowOnBlur){
    		user_WindowOnBlur();
    	}

    	return 0;
    }
    
    function user_WindowOnKeyPress(currWindow, e, keyCode) {
    	//return non-zero to disable system event handler
    	//your code here:

		// call page function if exists
    	if (window.page_WindowOnKeyPress){
    		page_WindowOnKeyPress();
    	}

    	return 0;
    }

	function user_WindowOnKeyDown(currWindow, e, keyCode) {
		//return non-zero to disable system event handler
		//your code here:

		// call page function if exists
    	if (window.page_WindowOnKeyDown){
    		page_WindowOnKeyDown();
    	}
		return 0;
	}

	function user_OverridePressedKey(key) {
		// return true to send the pressed key to the host. 
		// your code here:
		
		return true;
	}

    function user_prePostBack(){
    	//use this function to cancel submit of the form or an server button click action
    	//return false to disable sending of form data
    	//or true to proceed with sending the data to the host.
    	//your code here:
		
		return true;
    }
    
    function user_FormOnSubmit() {
    	//use this function to validate form input data.
    	//return false to disable sending of form data
    	//or true to proceed with sending the data to the host.
    	//your code here:

		// call page function if exists
    	if (window.page_FormOnSubmit){
    		page_FormOnSubmit();
    	}
    	return true;
    }
    
    
    
	function user_WindowOnDblClick(currWindow) {
    	//return non-zero to disable system event handler
    	//your code here:

		// call page function if exists
    	if (window.page_WindowOnDblClick){
    		page_WindowOnDblClick();
    	}
    	return 0;
	}

function SubmitCustomKey() {
	keyName = prompt('Enter key name:', '[enter]');
	if (keyName != null && keyName != '') {
		gx_SubmitKey(keyName);
	}
	return false;
}
function executePath() {
	pathName = prompt('Enter path name:', '<Enter path name>');
	if (pathName != null && pathName != '') {
		gx_ExecPath(pathName);
	}
	return false;
}
