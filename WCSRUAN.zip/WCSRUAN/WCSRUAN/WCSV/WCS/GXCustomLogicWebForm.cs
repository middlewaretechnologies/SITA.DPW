using System;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using com.sabratec.dotnet.framework;
using com.sabratec.applinx.baseobject;
using com.sabratec.dotnet.framework.web;


	/// <summary>
	/// Summary description for GXAbstractWebPage.
	/// </summary>
	public class GXCustomLogicWebForm : GXBasicWebForm
	{
		protected override void OnLoad(EventArgs e){

			try {
				gx_attach();

				//gx_syncFormWithHost();
				// or gx_syncHostWithForm();

				if (!Page.IsPostBack){
					gx_fillForm();
				}
			}
			catch(com.sabratec.applinx.baseobject.GXGeneralException err){
				gx_handleSessionError(err);
			}

			base.OnLoad(e);
		}
					
		protected override void OnInit(EventArgs e){
			//gx_appConfig.UseModalWindows = true;
			//gx_appConfig.ScreenLocker = "template\\screenLocker.ascx";
			//gx_appConfig.reflectHostCursor = true;
			base.OnInit(e);
		}
	}
