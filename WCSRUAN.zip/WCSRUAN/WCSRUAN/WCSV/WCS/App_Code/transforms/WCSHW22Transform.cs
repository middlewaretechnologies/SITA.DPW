using System;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;
using com.sabratec.applinx.baseobject;
using System.IO;
using System.Data;
using com.sabratec.util;
using com.sabratec.applinx.presentation.tags.html;
using System.Xml;
using System.Text;
using com.sabratec.dotnet.framework;
using System.Data.SqlClient;

	/// <summary>
	/// This class is receiving an event on the creation of each type of tag
	/// such as: "onNewlabel", "onNewLabel", "onNewButton", etc. It should be used for tag
	/// level manipulations, such as changing the content and attributes, adding icons, etc.
	/// </summary>
public class WCSHW22Transform : GXTagListener
{
	public override void onNewTextField(GXRenderEvent e, GXITextFieldTag textField) 
	{
		int testlength = textField.getId().Trim().Length;
		if (testlength >= 9)
		{
			if (textField.getId().Substring(0,9) == "BEGIN_KDE" || textField.getId().Substring(0,9) == "BEGIN_ALF")
			{
				textField.setText("");
			}
		}
	}		

}

