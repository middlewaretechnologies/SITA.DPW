using System;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;
using com.sabratec.applinx.baseobject;
using System.IO;
using System.Data;
using com.sabratec.util;
using com.sabratec.applinx.presentation.tags.html;
using System.Xml;
using System.Text;
using com.sabratec.dotnet.framework;
using System.Data.SqlClient;

	/// <summary>
	/// This class is receiving an event on the creation of each type of tag
	/// such as: "onNewTextField", "onNewLabel", "onNewButton", etc. It should be used for tag
	/// level manipulations, such as changing the content and attributes, adding icons, etc.
	/// </summary>
public class WCSLogonTransform : GXTagListener
{
	private string searchInd;
	private string txt;

		
	public override void onNewLabel(GXRenderEvent e, GXILabelTag label)
	{
		// Add here code that handles label fields (Host protected fields).
		// Use e parameter to access the screen tag model and the host screen.

		string ignoreWCS = "N";
		switch(label.getId().Trim())
		{
			case "USERID":
				ignoreWCS = "Y";
				break;
			default:
				break;
		}				
		if (ignoreWCS == "N")
		{
			searchInd = "WCS";
			if (label != null && label.getText().IndexOf(searchInd) >= 0)
			{
				txt = label.getText();
				txt =  txt.Replace("WCS","WIMS");
				label.setText(txt);
			}
		}
		searchInd = ".:";
		if (label != null && label.getText().IndexOf(searchInd) >= 0)
		{
			txt = label.getText();
			txt =  txt.Replace("..","");
			txt =  txt.Replace(" .","");
			txt =  txt.Replace(".:",":");
			label.setText(txt);
		}
		searchInd = "--";
		if (label != null && label.getText().IndexOf(searchInd) >= 0)
		{
			txt = label.getText();
			txt = txt.Replace("--","__");
			txt = txt.Replace("_-","__");
			txt = txt.Replace("+","_");
			txt = txt.Replace("_�","__");
			label.setText(txt);
		}
		searchInd = "�";
		if (label != null && label.getText().IndexOf(searchInd) >= 0)
		{
			txt = label.getText();
			txt = txt.Replace("�","");
			label.setText(txt);
		}
	}
	public override void onNewTextField(GXRenderEvent e,GXITextFieldTag textField) 
	{
		// Add here code that handles text fields (Host unprotected fields).
		// Use e parameter to access the screen tag model and the host screen.
		//if (textField.getId().Trim() == "USERID")
		//{
		//	textField.setText("WCS001");
		//}

		//if (textField.getId().Trim() == "PASSWRD")
		//{
		//	textField.removeAttribute("type");
		//	textField.setAttribute("value=","jsj@0821");
		//	textField.setLength(8);
		//	textField.setAttribute("type","password");
			//textField.setAttribute("value","JSJ@0821");
			//textField.setAttribute("type","password");
		//	string strUserPassword = FormsAuthentication.HashPasswordForStoringInConfigFile(textField.setText(),"jsj@0821");

		//}
	}
}

