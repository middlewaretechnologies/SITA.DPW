using com.sabratec.applinx.baseobject;
using com.sabratec.applinx.presentation;
using com.sabratec.applinx.presentation.queries;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;
using com.sabratec.applinx.presentation.tags.html;
using com.sabratec.util;

	/// <summary>
	/// This class is receiving an "onComplete" event, 
	/// which should be used for manipulating the entire tag model.
	/// </summary>
/**
 * This transformation handles menu screens. It removes unrequired labels from the menu 
 * screen and builds an HTML table with the menu items appearing as links.
 * Handles transformation for the following maps:
 * 
 *			IS0003
 */
public class WCSMenuTransform :GXICompletionListener
{
	/**
	 * Hides elements that are not required to be displayed
	 * @param screenModel
	 *          The screen tag model whose elements should be hidden 
	 */
	private void hideElements(GXIScreenTagModel screenModel)
	{
		/** Executes a query for fields that contain one of the strings and hides them */
		GXTextQuery mailQuery = new GXTextQuery("INBASKET :");
		GXTagList mailList = screenModel.executeQuery(mailQuery);

		for(int i=0;i<mailList.getCount();i++)
		{
			mailList.get(i).setVisible(false);

			GXHtmlGenericTag inbasketImg = GXHtmlTagFactory.instance().newGenericTag("img");
			inbasketImg.setAttribute("src","images/inbasket.gif");
			inbasketImg.setAttribute("class","inbasketImg");
			inbasketImg.setAttribute("onmouseover","window.status='Message';return true;");
			inbasketImg.setAttribute("title","Message");
			inbasketImg.setAttribute("onmouseout","window.status='';return true;");
			inbasketImg.setPosition(1,95);
			inbasketImg.setAttribute("onclick","gx_SubmitKey('[pf16]')");
			screenModel.add(inbasketImg);
		}

		GXTextQuery nextMenuQuery = new GXTextQuery("PRESS ENTER FOR MORE FUNCTIONS");
		GXTagList nextMenuList = screenModel.executeQuery(nextMenuQuery);

		for(int i=0;i<nextMenuList.getCount();i++)
		{
			nextMenuList.get(i).setVisible(false);

			GXILabelTag nextMenuLbl = GXHtmlTagFactory.instance().newLabel("More Functions");
			nextMenuLbl.setAttribute("class","nextMenuLbl");
			nextMenuLbl.setAttribute("onclick","gx_SubmitKey('[enter]')");
			nextMenuLbl.setAttribute("onmouseover","window.status='More Functions';this.className='nextMenuLbl_over';return true");
			nextMenuLbl.setAttribute("onmouseout","window.status='';this.className='nextMenuLbl_out';return true");
			screenModel.add(nextMenuLbl);
			GXHtmlGenericTag nextMenuImg = GXHtmlTagFactory.instance().newGenericTag("img");
			nextMenuImg.setAttribute("src","images/next_menu.gif");
			nextMenuImg.setAttribute("class","nextMenuImg");
			nextMenuImg.setAttribute("title","More Functions");
			nextMenuImg.setAttribute("onclick","gx_SubmitKey('[enter]')");
			screenModel.add(nextMenuImg);
		}

		
		GXTextQuery query = new GXTextQuery("OPTION:");
		query.addSearchText("PRESS ENTER FOR MORE FUNCTIONS");
				
		GXTagList list = screenModel.executeQuery(query);

			for(int i=0;i<list.getCount();i++)
				{
					list.get(i).setVisible(false);
				}

				/** also hides the Selection text field */
				hideSelectionField(screenModel);
	}
	
	/**
	 * Builds a table with menu items.
	 * Each menu text is created as a table cell.
	 * The menu number is not displayed.
	 * The link activates a JavaScript function <code>placeMenuOption</code> which places the number
	 * within the Selection text field.
	 * The JavaScript function is located in the js/general.js file
	 * @param screenModel
	 *          The screen tag model which should contain the menu items.   
	 */
	private void handleMenuItems(GXIScreenTagModel screenModel)
	{

		GXAreaQuery areaQuery = new GXAreaQuery(8,22);

		GXTagList list = screenModel.executeQuery(areaQuery);
		
		GXITableTag tableText = GXHtmlTagFactory.instance().newTable();
		
		GXITableRowTag trText = null;
		GXITableCellTag tcText = null;
		
		GXITableTag tableButton = GXHtmlTagFactory.instance().newTable();
		GXITableRowTag trButton = null;
		GXITableCellTag tcButton = null;
		GXILinkTag hrefButton = null;
		GXHtmlGenericTag imgButton = null;
		string buttonColor = "gray_button";
				
		for(int i=0;i<list.getCount();i=i+4)
		{
			tcText = GXHtmlTagFactory.instance().newTableCell();
   
			GXILabelTag currentTag = (GXILabelTag)list.get(i);
			string optionNumber = currentTag.getText().Replace(".","").Trim();

			if (optionNumber != null && optionNumber.Trim().Length > 0)
			{
				try
				{
					/** Checks if the option text is a number */
					int optionNumberInt = System.Int32.Parse(optionNumber);

					string text = ((GXILabelTag)list.get(i+3)).getText().Trim();
					string text1 = text.ToLower();
					string text2 = text1.Substring(0,1).ToUpper();
					string text3 = text1.Remove(0,1);
					text = text2 + text3;
					string shortText = ((GXILabelTag)list.get(i+1)).getText().Trim();
					if (shortText == "WCS")
					{
						shortText = "WIMS";
					}
					if (text == "Works control system")
					{
						text = "Works information management system";
					}
					tcText.setText(text);
					if (buttonColor == "gray_button")
					{
						buttonColor = "brown_button";
						tcText.setAttribute("class","menu_brown_cell");
						tcText.setAttribute("onmouseout","window.status='';this.className='menu_brown_cell';return true;");
						tcText.setAttribute("onmouseover","window.status='" + shortText + "';this.className='menu_brown_cell_over';return true;");
					}
					else
					{
						buttonColor = "gray_button";
						tcText.setAttribute("class","menu_gray_cell");
						tcText.setAttribute("onmouseout","window.status=''; this.className='menu_gray_cell';return true;");
						tcText.setAttribute("onmouseover","window.status='" + shortText + "';this.className='menu_gray_cell_over';return true;");
					}
					tcText.setAttribute("onclick","placeMenuOption('" + optionNumber + "')");
					tcText.setAttribute("title",shortText);
										
					/** Locate it as the menu option text*/
				
					trText = GXHtmlTagFactory.instance().newTableRow();
					tableText.getRows().add(trText);
					trText.getCells().add(tcText);

					
					list.get(i).setVisible(false);
					list.get(i+1).setVisible(false);
					list.get(i+2).setVisible(false);
					list.get(i+3).setVisible(false);

					tcButton = GXHtmlTagFactory.instance().newTableCell();
					imgButton = GXHtmlTagFactory.instance().newGenericTag("img");
					hrefButton = GXHtmlTagFactory.instance().newLink("");

					tcButton.setAttribute("class", "buttonTD");
					tcButton.setAttribute("align", "center");
					
					imgButton.setAttribute("src", "images/" + buttonColor + ".gif");
					
					trButton = GXHtmlTagFactory.instance().newTableRow();
					trButton.setAttribute("class", "buttonRow");
					tableButton.getRows().add(trButton);

					hrefButton.getChildren().add(imgButton);
					tcButton.getChildren().add(hrefButton);
					trButton.getCells().add(tcButton);
				}

				catch //(System.FormatException err)
				{
					/** Ignore when the text without the dot is not a number */
				}
				
			}
		}
		//tableText.setPosition(list.get(0).getPosition());
		tableText.setAttribute("class","menu_table");
		screenModel.add(tableText);

		tableButton.setAttribute("class", "buttonTable");
		tableButton.setVisible(true, true);
		screenModel.add(tableButton);

		// Add Command Line wording to screen

		GXILabelTag commandLineLbl = GXHtmlTagFactory.instance().newLabel("Command Line");
		commandLineLbl.setAttribute("class","commandlinetext");
		screenModel.add(commandLineLbl);
			
	}
	
	/**
	 * Hides the selection menu field
	 * @param screeenModel
	 *      the screen tag model which contains the Selection field
	 */
	public void hideSelectionField(GXIScreenTagModel screeenModel) 
	{

		/** Checks if the field is the selection field */
		GXITag selectionTag;
		try 
		{
			selectionTag = screeenModel.executePositionQuery(23,13);
		} 
		catch //(GXIllegalPositionException e) 
		{
			return;
		}

		if (selectionTag != null)
		{
			selectionTag.setVisible(false,true); // render the tag with: style="display:none"
		}
	}

	public void onComplete(GXRenderEvent e) 
	{
		hideElements(e.getScreenTagModel());
		handleMenuItems(e.getScreenTagModel());
	}

}