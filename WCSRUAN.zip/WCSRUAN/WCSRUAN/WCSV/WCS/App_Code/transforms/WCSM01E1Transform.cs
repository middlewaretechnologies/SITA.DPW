using com.sabratec.applinx.baseobject;
using com.sabratec.applinx.presentation;
using com.sabratec.applinx.presentation.queries;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;
using com.sabratec.applinx.presentation.tags.html;
using com.sabratec.util;

	/// <summary>
	/// This class is receiving an "onComplete" event, 
	/// which should be used for manipulating the entire tag model.
	/// </summary>
/**
 * This transformation handles menu screens. It removes unrequired labels from the menu 
 * screen and builds an HTML table with the menu items appearing as links.
 * 
 * Handles transformation for the following maps:
 * 
 *			Database selection
 */
public class WCSM01E1Transform :GXICompletionListener
{
	public string imgId;
	public string lblId;

	public void setEnvId(string envID)
	{
		lblId = envID;
		if (envID == "Production")
		{
			imgId ="images/env_prod.gif";
		}
		else
		{
			if (envID == "Test")
			{
				imgId ="images/env_test.gif";
			}
			else
			{
				if (envID == "Development")
				{
					imgId ="images/env_dev.gif";
				}
				else
				{
					imgId ="images/env_logoff.gif";
				}
			}
		}
	}
	private void handleMenuItems(GXIScreenTagModel screenModel)
	{
		GXHtmlGenericTag logonImg = GXHtmlTagFactory.instance().newGenericTag("img");
		logonImg.setAttribute("src",imgId);
		logonImg.setAttribute("class","env_logon_img");
		screenModel.add(logonImg);

		GXILabelTag logonLbl = GXHtmlTagFactory.instance().newLabel("logonLbl");
		logonLbl.setAttribute("class","env_logon_text");
		logonLbl.setText(lblId);
		logonLbl.setAttribute("title",lblId);
		screenModel.add(logonLbl);

	}
	public void onComplete(GXRenderEvent e) 
	{
		handleMenuItems(e.getScreenTagModel());	
	}

}