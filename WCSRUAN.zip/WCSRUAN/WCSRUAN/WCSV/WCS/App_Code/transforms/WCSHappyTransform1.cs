using System;
using com.sabratec.applinx.presentation.@event;
using com.sabratec.applinx.presentation.tags;
using com.sabratec.applinx.presentation.tags.html;
using System.Web;




	/// <summary>
	/// This class is receiving an event on the creation of each type of tag
	/// such as: "onNewTextField", "onNewLabel", "onNewButton", etc. It should be used for tag
	/// level manipulations, such as changing the content and attributes, adding icons, etc.
	/// </summary>
	public class WCSHappyTransform1 : GXTagListener
	{

		public override void onNewTextField(GXRenderEvent e,GXITextFieldTag textField) 
		{
			// Add here code that handles text fields (Host unprotected fields).
			// Use e parameter to access the screen tag model and the host screen.
			if (textField.getId().Trim() == "G1_COMMAND")
			{
				if (textField.getContent().Trim() == "** HAPPY BIRTHDAY **")
				{
					textField.setText("");
					HttpCookie myCookie = HttpContext.Current.Request.Cookies["happy"];
					myCookie.Values.Clear();
					myCookie.Values.Add("happyInd", "birthday 1");
					HttpContext.Current.Response.Cookies.Add(myCookie);
				}
				HttpCookie myHappyCookie = HttpContext.Current.Request.Cookies["happy"];
				string myHappy = (string)myHappyCookie.Values[(0)];
				if (myHappy != "no birthday")
				{
					if (myHappy == "birthday 1")
					{
						GXHtmlGenericTag happyImg = GXHtmlTagFactory.instance().newGenericTag("img");
						happyImg.setAttribute("src","images/happy_birthday1.gif");
						happyImg.setAttribute("id","happyImg");
						e.getScreenTagModel().add(happyImg);
						myHappyCookie.Values.Clear();
						myHappyCookie.Values.Add("happyInd", "birthday 2");
						HttpContext.Current.Response.Cookies.Add(myHappyCookie);
					}
					else
					{
						if (myHappy == "birthday 2")
						{
							GXHtmlGenericTag happyImg = GXHtmlTagFactory.instance().newGenericTag("img");
							happyImg.setAttribute("src","images/happy_birthday2.gif");
							happyImg.setAttribute("id","happyImg");
							e.getScreenTagModel().add(happyImg);
						}
					}
				}
			}
		}
	}
