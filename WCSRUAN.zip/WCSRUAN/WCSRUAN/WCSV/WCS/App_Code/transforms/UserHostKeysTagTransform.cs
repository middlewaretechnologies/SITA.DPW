using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using com.sabratec.applinx.baseobject;
using com.sabratec.applinx.framework.web.hostkeys;
using com.sabratec.applinx.presentation.tags;
using com.sabratec.applinx.presentation.tags.html;

public class UserHostKeysTagTransform : GXHostKeysTagUserExit
{
    public UserHostKeysTagTransform()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public override void onHostKeysComplete(GXITableTag hostKeysTableTag, GXIScreen screen)
    {
        /*
        base.onHostKeysComplete(hostKeysTableTag, screen);
        
        //add link
        addLink("Host help", "gx_SubmitKey('[pf1]')");

        //get all tags
        GXITag[] tags = getHostKeysTags();

        //loop on tage in hostKeys array
        foreach (GXITag tag in tags)
        {
            if (tag is GXILinkTag)  // or GXIButtonTag or GXHtmlString (for type="template")
            {
                //get link
                GXILinkTag link = (GXILinkTag)tag;
                
                // change tag text
                if (link.getText().IndexOf("Prev") >= 0)
                {
                    link.setText("Previous");
                }

                //remove tag
                if (link.getText().IndexOf("Pagedn") >= 0)
                {
                    removeTag(link);
                }
            }
        }
        */
    }
}
