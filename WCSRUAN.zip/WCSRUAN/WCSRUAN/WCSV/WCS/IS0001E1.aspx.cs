using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace WCS
{
	/// <summary>
	/// Summary description for IS0001E1.
	/// </summary>
	public partial class IS0001E1 : GXInstantLogicWebForm
	{
		// protected com.sabratec.dotnet.framework.web.controls.GXInstantRenderer GXInstantRenderer1;
		// protected System.Web.UI.HtmlControls.HtmlGenericControl theScrape;
	
		private void Page_Load(object sender, System.EventArgs e)
		{

			// Put user code to initialize the page here
		}
		public override void registerInstantTransforms() 
		{

			HttpCookie myCookie = Request.Cookies["enviroment"];
			WCSM01E1Transform x = new WCSM01E1Transform();
			if (myCookie != null)
			{
				x.setEnvId(myCookie.Values[(0)]);
			}
			gx_appConfig.InstantConfig.addCompletionListener(x);

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Init += new System.EventHandler(this.Page_Init);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Init(object sender, System.EventArgs e)
		{
			HttpCookie myAppCookie = Request.Cookies["myApp"];
			string myApp = (string)myAppCookie.Values[(0)];
			if (myApp == "ECDP")
			{
				Response.Write("<link id='logon_ecdp' href='css/ecdp_other.css' type='text/css' rel='STYLESHEET'></link>");
			}
			else
			{
				Response.Write("<link id='logon_wims' href='css/wims_other.css' type='text/css' rel='STYLESHEET'></link>");
			}
		}
	}
}
