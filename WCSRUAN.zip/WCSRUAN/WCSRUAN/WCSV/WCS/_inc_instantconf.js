/*
*  configuration file for browser emulation behaviour
*  for the instant page only .
*  to declare just for te entire project, declare only in : _inc_applconf.js
*  see ApplinX help files -> ApplinX HTML Emulation.pdf for complete documentation
*
*/

GX_MarkLabel = GX_MarkLabelBold; // GX_MarkLabelUnderline ,GX_MarkLabelNone , GX_MarkLabelBold
//GX_UseArrows = GX_UseArrowsOnInputs;  //GX_UseArrowsNone,GX_UseArrowsOnInputs, GX_UseArrowsOnInputsToNextLine

//GX_FieldInsertMode = true;

GX_TabOnInputsOnly = true;
//GX_EnableMenuSelection = true;

GX_CaptureInputTagEvents = true;
GX_CaptureLabelTDTagEvents = true;

//GX_WarnOnBrowserClose = true;
//GX_LogoffOnBrowserClose = true;

//GX_EnableAutoEnter = true;
//GX_EnableAS400FieldPlus = true;
//GX_HandleCtrlAsEnter = false;
//GX_ShowBlinkFields = true;

GX_EnableDoubleClickAsEnter = true;

//var GX_LockFormOnSubmit = false; // ApplinX locks the form by default

//var ctrl_K66='myJSFunction';  // ctrl+B

//var K17= 'gx_newLine'; // ctrl

//var K13= 'gx_newLine'; // enter 
// use also : GX_HandleCtrlAsEnter = true;

/*
availalble to use ApplinX emulation function
- gx_home
- gx_end
- gx_newLine
- gx_SubmitSysReq
*/

/*
// sample function 
function myJSFunction(){
	curTextBox = event.srcElement;
	keyPressed = event.keyCode;
	// ...
}
*/


/*

// examples how to use customized codes

var ctrl_K65='[pf13]';  // ctrl+A  = pf13
var shift_K49='[pf1]';  // shift+1 = pf1
var K50='[pf9]';        // 2 = pf9

// Refer to the framework developer's guide for the key codes table

*/


