using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using com.sabratec.applinx.baseobject;

	/// <summary>
	/// Summary description for instant.
	/// </summary>
	public class instantWin : GXInstantLogicWebForm
	{
		protected com.sabratec.dotnet.framework.web.controls.GXInstantRenderer GXInstantRenderer1;
		protected Literal appNameTitle;

		private void InitializeComponent()
		{
			this.Init += new System.EventHandler(this.Page_Init);

		}
	
		protected override void OnLoad(System.EventArgs e)
		{
			if (appNameTitle != null){
				appNameTitle.Text = gx_appConfig.SessionConfig.ApplicationName;
			}
			base.OnLoad(e);

		}

		private void Page_Init(object sender, System.EventArgs e)
		{
			HttpCookie myAppCookie = Request.Cookies["myApp"];
			string myApp = (string)myAppCookie.Values[(0)];
			if (myApp == "ECDP")
			{
				Response.Write("<link id='logon_ecdp' href='css/ecdp.css' type='text/css' rel='STYLESHEET'></link>");
			}
			else
			{
				Response.Write("<link id='logon_wims' href='css/wims.css' type='text/css' rel='STYLESHEET'></link>");
			}
		}
	}
